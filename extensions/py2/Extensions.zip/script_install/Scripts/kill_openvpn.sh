##!/bin/sh
killall -9 openvpn