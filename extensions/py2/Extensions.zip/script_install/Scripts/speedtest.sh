#/bin/bash
wget -qO- http://ipecho.net/plain | xargs echo -e "Your IP Address is:\n"

/usr/lib/enigma2/python/Plugins/Extensions/script_install/oscupdate/speedtest --accept-license
