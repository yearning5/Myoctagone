#/bin/bash
ntpdate time.nist.gov