#!/bin/sh
python /usr/lib/enigma2/python/Plugins/Extensions/script_install/oscupdate/mire.py