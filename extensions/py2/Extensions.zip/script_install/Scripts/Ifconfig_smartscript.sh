#!/bin/sh
#DESCRIPTION= it shows internet configuration
ifconfig

