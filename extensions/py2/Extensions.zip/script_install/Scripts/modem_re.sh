#!/bin/sh
{
sleep 2
echo root
sleep 2
echo Guira1975
sleep 2
echo reboot
sleep 5
} | telnet 192.168.1.1
