##!/bin/sh
python /usr/lib/enigma2/python/Plugins/Extensions/script_install/oscupdate/ovpn_file.py