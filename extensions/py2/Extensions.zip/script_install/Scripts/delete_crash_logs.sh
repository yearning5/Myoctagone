#!/bin/sh
#Franc - 2018 (PurE2)

printf "Searching for crash logs, please wait... \n"
#export crashfilename=`find / -name enigma2_crash*`
#export crashfilename='find /home -name *crash*.log'
echo "."
echo ".."
#rm -f $crashfilename
find /home -name *crash*.log -exec rm -f {} \;
sleep 1
echo "..."
echo "done!"
echo " "
exit 0
