#!/bin/bash
python /usr/lib/enigma2/python/Plugins/Extensions/script_install/oscupdate/aumaletv.py && wget -qO - http://127.0.0.1/web/servicelistreload?mode=2

