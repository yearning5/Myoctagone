#/usr/bin/sh
/etc/init.d/networking restart

