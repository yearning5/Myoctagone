# Ihad.tv enigma2-plugin tutorial 2010
# lesson 4
# by emanuel
from Screens.Screen import Screen
from Screens.Console import Console
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Screens.MessageBox import MessageBox
from Plugins.Plugin import PluginDescriptor
import json,os
###########################################################################

#with open('/usr/lib/enigma2/python/Plugins/Extensions/script_install/commandlist.txt') as f:
#    flist=f.readlines()
with open('/usr/lib/enigma2/python/Plugins/Extensions/script_install/packages.json') as f:
    flist2=f.read()
#list = [ (flist[i],str(i+1)) for i in range(len(flist)) ]
data=json.loads(flist2)
data1=data['plugins']
data2=data['package']
flist22=[]
flist22.append('packages')
flist22.append('================================')
flist22.append('My_scripts')
flist22.append('================================')
flist22+=[ str(i) for i in sorted(data['plugins'].keys())]
flist3= [ (flist22[i],str(i+1)) for i in range(len(flist22)) ]
flist3.append(('Exit', 'exit'))
flist4=[ (str(data['package'][i]),str(i+1)) for i in range(len(data['package'])) ]
flist4.append(('Exit', 'exit'))
flist55=os.listdir(r'/usr/lib/enigma2/python/Plugins/Extensions/script_install/Scripts')
flist55=sorted(flist55, key=lambda s: s.lower())
flist5=[ (str(flist55[i]),str(i+1)) for i in range(len(flist55)) ]
flist5.append(('Exit', 'exit'))


class MyMenu(Screen):
    skin = """
    <screen position="center,center" size="920,800" title="Script Installtion .....">
    <widget name="myMenu" position="10,10" size="840,760" scrollbarMode="showOnDemand" font="Regular; 28" itemHeight="55" />
    </screen>"""
    
   
    
    def __init__(self, session, args = 0):
        self.session = session
        Screen.__init__(self, session)
        self["myMenu"] = MenuList(flist3)
        self["myActionMap"] = ActionMap(["SetupActions"],
        {
        "ok": self.go,
        "cancel": self.cancel
        }, -1)
    
    def go(self):
        self.returnValue = self["myMenu"].l.getCurrentSelection()[0]
        print "\n[MyMenu] returnValue: " + self.returnValue + "\n"
        print type(self.returnValue)
        if self.returnValue is not None:
            if self.returnValue == 'Exit':
                print( "\n[MyMenu] cancel\n")
                self.close(None)
            elif  self.returnValue == 'packages':
                self.session.open(MyMenu2)
            elif  self.returnValue == 'My_scripts':
                self.session.open(MyMenu3)
            elif  self.returnValue == '================================':
                print( "\n[MyMenu] cancel\n")
            else:
                self.session.openWithCallback(self.installpackage, MessageBox, _('Do you wanna Install '+self.returnValue+' ?'), MessageBox.TYPE_YESNO)
        else:
            print "\n[MyMenu] cancel\n"
            self.close(None)
    def cancel(self):
        print "\n[MyMenu] cancel\n"
        self.close(None)
    def installpackage(self, result):
        if result:
            self.prombt(data1[self.returnValue])
        else:
            print "\n[MyMenu] cancel\n"
            #self.close(None)
    def prombt(self, com):
        self.session.open(Console,_("start shell com:") , ["%s" % com])


class MyMenu2(Screen):
    skin = """
    <screen position="center,center" size="920,800" title="INSTALL Extra Packages ....">
    <widget name="myMenu2" position="10,10" size="840,760" scrollbarMode="showOnDemand" font="Regular; 28" itemHeight="55" />
    </screen>"""
    
    def __init__(self, session, args = 0):
        self.session = session
        Screen.__init__(self, session)
        self["myMenu2"] = MenuList(flist4)
        self["myActionMap"] = ActionMap(["SetupActions"],
        {
        "ok": self.go,
        "cancel": self.cancel
        }, -1)
    
    def go(self):
        self.returnValue = self["myMenu2"].l.getCurrentSelection()[0]
        if self.returnValue is not None:
            if self.returnValue == 'Exit':
                print "\n[MyMenu] cancel\n"
                self.close(None)
            else:
                self.session.openWithCallback(self.installpackage, MessageBox, _('Do you wanna Install '+self.returnValue+' ?'), MessageBox.TYPE_YESNO)
        else:
            print "\n[MyMenu] cancel\n"
            self.close(None)
    def installpackage(self, result):
        if result:
            self.prombt("opkg install "+str(self.returnValue))
        else:
            self.close(None)
    def cancel(self):
        print "\n[MyMenu] cancel\n"
        self.close(None)
    def prombt(self, com):
        self.session.open(Console,_("start shell com:") , ["%s" % com])
   
class MyMenu3(Screen):
    skin = """
    <screen position="center,center" size="920,800" title="Personal GUIRA Script Installtion .....">
    <widget name="myMenu3" position="10,10" size="840,760" scrollbarMode="showOnDemand" font="Regular; 28" itemHeight="55" />
    </screen>"""

    def __init__(self, session, args = 0):
        self.session = session
        Screen.__init__(self, session)
        self["myMenu3"] = MenuList(flist5)
        self["myActionMap"] = ActionMap(["SetupActions"],
        {
        "ok": self.go,
        "cancel": self.cancel
        }, -1)
    
    def go(self):
        self.returnValue = self["myMenu3"].l.getCurrentSelection()[0]
        print "\n[MyMenu] returnValue: " + self.returnValue + "\n"
        print type(self.returnValue)
        if self.returnValue is not None:
            if self.returnValue == 'Exit':
                print( "\n[MyMenu] cancel\n")
                self.close(None)
            else:
                self.session.openWithCallback(self.installpackage, MessageBox, _('Do you wanna Install '+self.returnValue+' ?'), MessageBox.TYPE_YESNO)
        else:
            print "\n[MyMenu] cancel\n"
            self.close(None)
    def cancel(self):
        print "\n[MyMenu] cancel\n"
        self.close(None)
    def installpackage(self, result):
        if result:
            self.prombt("/usr/lib/enigma2/python/Plugins/Extensions/script_install/Scripts/"+str(self.returnValue))
        else:
            self.close(None)
    def prombt(self, com):
        self.session.open(Console,_("start shell com:") , ["%s" % com])  

        
###########################################################################
def main(session, **kwargs):
    print "\n[MyMenu] start\n"
    session.open(MyMenu)
###########################################################################
def Plugins(**kwargs):
    return PluginDescriptor(
    name="Plugins Installer Script",
    description="Simple scripts for Enigma 2",
    where = PluginDescriptor.WHERE_PLUGINMENU,
    icon="Script.png",
    fnc=main)
