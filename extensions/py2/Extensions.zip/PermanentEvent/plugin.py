## Permanent Event ## by AliAbdul ## mod by Maggy 
from Components.ActionMap import ActionMap
from Components.config import config, ConfigInteger, ConfigSubsection, ConfigYesNo, getConfigListEntry, ConfigSelection, KEY_LEFT, KEY_RIGHT
from Components.Language import language
from Components.MenuList import MenuList
from Components.ConfigList import ConfigList
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.Pixmap import Pixmap
from enigma import ePoint, eTimer, getDesktop
from GlobalActions import globalActionMap
from keymapparser import readKeymap, removeKeymap
from os import environ
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
import gettext
dwidth = getDesktop(0).size().width()
##############################################################################

config.plugins.PermanentEvent = ConfigSubsection()
config.plugins.PermanentEvent.enabled = ConfigYesNo(default=False)
config.plugins.PermanentEvent.position_x = ConfigInteger(default=8)
config.plugins.PermanentEvent.position_y = ConfigInteger(default=4)
config.plugins.PermanentEvent.par1 = ConfigYesNo(default=False)
config.plugins.PermanentEvent.show_hide = ConfigYesNo(default=False)
config.plugins.PermanentEvent.color_analog = ConfigSelection([("1", _("maggy-style")),("2", _("maggy-breitling")),("3", _("maggy-tissot")),("4", _("maggy-ferrari")),("5", _("maggy-rolex")),("6", _("maggy-grand carrera")),("7", _("maggy-style2")),("8", _("maggy-style3")),("9", _("grey-metallic")),("10", _("black-yellow")),("11", _("atile-style")),("12", _("maggy-tron")),("13", _("maggy-globe")),("14", _("maggy-black")),("15", _("maggy-black-gold")),("16", _("maggy-omega")),("17", _("maggy-gt")),("18", _("sliver-red")),("19", _("hsv")),("20", _("fcb")),("21", _("bcb")),("22", _("christmas")),("23", _("carrera")),("24", _("porsche")),("25", _("nixon")),("26", _("luminor")),("27", _("blue")),("28", _("d-g")),("29", _("g-shock")),("30", _("maggy-carbon"))], default="1")


##############################################################################

def localeInit():
	lang = language.getLanguage()
	environ["LANGUAGE"] = lang[:2]
	gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
	gettext.textdomain("enigma2")
	gettext.bindtextdomain("PermanentEvent", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/PermanentEvent/locale/"))

def _(txt):
	t = gettext.dgettext("PermanentEvent", txt)
	if t == txt:
		t = gettext.gettext(txt)
	return t

localeInit()
language.addCallback(localeInit)

from enigma import addFont
try:
    addFont("/usr/lib/enigma2/python/Plugins/Extensions/PermanentEvent/font/metal-mania.regular.ttf", "My1", 100, 1)
    addFont("/usr/lib/enigma2/python/Plugins/Extensions/PermanentEvent/font/EventHD.ttf", "My2", 100, 1)
    
except:
    pass
##############################################################################

##############################################################################
if dwidth == 1920:
    SKIN = """
    <screen name="" position="8,9" size="693,84" zPosition="-1" transparent="0" backgroundColor="transparent" title="%s" flags="wfNoBorder">
    <widget source="session.Event_Now" render="Label" emptyText="Event Data Unavailable" position="0,39" size="700,42" foregroundColor="#33ccff" font="My1; 38" halign="left" valign="center" backgroundColor="black" transparent="1" zPosition="7">
    <convert type="EventName">Name</convert>
    </widget>
    <eLabel text="You're watching ......" name="" position="0,0" size="370,42" foregroundColor="#ffd633" font="My2; 30" transparent="1" />
</screen>""" % _("Permanent Event")

else:
    SKIN = """
	<screen name="" position="5,4" size="400,25" zPosition="-1" transparent="0" backgroundColor="transparent" title="%s" flags="wfNoBorder">
    <widget source="session.Event_Now" render="Label" emptyText="Event Data Unavailable" position="0,0" size="400,25" foregroundColor="#33ccff" font="Regular; 25"  halign="left" valign="center" backgroundColor="black" transparent="1" zPosition="7">
    <convert type="EventName">Name</convert>
    </widget>
    </screen>""" % _("Permanent Event")



class PermanentEventNewScreen(Screen):
	def __init__(self, session):
		self.skin = SKIN
		     
		Screen.__init__(self, session)
	    
		self.onShow.append(self.movePosition)

	def movePosition(self):
		if self.instance:
			self.instance.move(ePoint(config.plugins.PermanentEvent.position_x.value, config.plugins.PermanentEvent.position_y.value))

##############################################################################

class PermanentEvent():
	def __init__(self):
		self.dialog = None
		self.clockShown = False
		self.clockey = False
		
	def gotSession(self, session):
		self.dialog = session.instantiateDialog(PermanentEventNewScreen)
		self.showHide()
		self.start_key()
		
	def start_key(self):
		global globalActionMap
		if config.plugins.PermanentEvent.show_hide.value and self.clockey == False:
			readKeymap("/usr/lib/enigma2/python/Plugins/Extensions/PermanentEvent/keymap.xml")
			globalActionMap.actions['showClock'] = self.ShowHideKey
			self.clockey = True

	def unload_key(self):
		if not config.plugins.PermanentEvent.show_hide.value and self.clockey == True:
			removeKeymap("/usr/lib/enigma2/python/Plugins/Extensions/PermanentEvent/keymap.xml")
			if 'showClock' in globalActionMap.actions:
				del globalActionMap.actions['showClock']
			self.clockey = False
			
	def ShowHideKey(self):
		if config.plugins.PermanentEvent.enabled.value:
			if self.clockShown:
				self.clockShown = False
				self.dialog.show()
			else:
				self.clockShown = True
				self.dialog.hide()
	
	
	def changeVisibility(self):
		if config.plugins.PermanentEvent.enabled.value:
			config.plugins.PermanentEvent.enabled.value = False
		else:
			config.plugins.PermanentEvent.enabled.value = True
		config.plugins.PermanentEvent.enabled.save()
		self.showHide()

	def changeAnalog(self):
		if config.plugins.PermanentEvent.par1.value:
			config.plugins.PermanentEvent.par1.value = False
		else:
			config.plugins.PermanentEvent.par1.value = True
		config.plugins.PermanentEvent.par1.save()
		self.dialog = None
		
	def ColorAnalog(self):
		config.plugins.PermanentEvent.color_analog.save()
		self.dialog = None
		
	def changeKey(self):
		if config.plugins.PermanentEvent.show_hide.value:
			config.plugins.PermanentEvent.show_hide.value = False
		else:
			config.plugins.PermanentEvent.show_hide.value = True
		config.plugins.PermanentEvent.show_hide.save()	
		
	def showHide(self):
		if config.plugins.PermanentEvent.enabled.value:
			self.dialog.show()
		else:
			self.dialog.hide()

pClock = PermanentEvent()

##############################################################################

class PermanentEventPositioner(Screen):
	def __init__(self, session):
		self.skin = SKIN
		Screen.__init__(self, session)
	
		
		self["actions"] = ActionMap(["WizardActions"],
		{
			"left": self.left,
			"up": self.up,
			"right": self.right,
			"down": self.down,
			"ok": self.ok,
			"back": self.exit
		}, -1)
		
		desktop = getDesktop(0)
		self.desktopWidth = desktop.size().width()
		self.desktopHeight = desktop.size().height()
		
		self.moveTimer = eTimer()
		self.moveTimer.callback.append(self.movePosition)
		self.moveTimer.start(50, 1)

	def movePosition(self):
		self.instance.move(ePoint(config.plugins.PermanentEvent.position_x.value, config.plugins.PermanentEvent.position_y.value))
		self.moveTimer.start(50, 1)

	def left(self):
		value = config.plugins.PermanentEvent.position_x.value
		value -= 25
		if value < 0:
			value = 0
		config.plugins.PermanentEvent.position_x.value = value

	def up(self):
		value = config.plugins.PermanentEvent.position_y.value
		value -= 25
		if value < 0:
			value = 0
		config.plugins.PermanentEvent.position_y.value = value

	def right(self):
		value = config.plugins.PermanentEvent.position_x.value
		value += 25
		if value > self.desktopWidth:
			value = self.desktopWidth
		config.plugins.PermanentEvent.position_x.value = value

	def down(self):
		value = config.plugins.PermanentEvent.position_y.value
		value += 25
		if value > self.desktopHeight:
			value = self.desktopHeight
		config.plugins.PermanentEvent.position_y.value = value

	def ok(self):
		config.plugins.PermanentEvent.position_x.save()
		config.plugins.PermanentEvent.position_y.save()
		self.close()

	def exit(self):
		config.plugins.PermanentEvent.position_x.cancel()
		config.plugins.PermanentEvent.position_y.cancel()
		self.close()

##############################################################################

class PermanentEventMenu(Screen):
    if dwidth == 1920:
        skin="""
        <screen name="" position="564,216" size="820,397" title="Permanent Event Setup">
            <widget name="list" position="10,10" size="802,382" />
        </screen>"""
    else:
        skin = """
		<screen position="center,center" size="410,155" title="Permanent Event Setup">
			<widget name="list" position="10,10" size="400,145" />
		</screen>""" 
    def __init__(self, session):
		Screen.__init__(self, session)
		self.session = session
		self["list"] = MenuList([])
		self.setTitle(_("Permanent Event Setup"))
		self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.okClicked, "cancel": self.close}, -1)
		self.onLayoutFinish.append(self.showMenu)


    def showMenu(self):
		list = []
		if config.plugins.PermanentEvent.enabled.value:
			list.append(_("Deactivate Permanent Event"))
			list.append(_("Change Permanent Event position"))
		else:
			list.append(_("Activate Permanent Event"))
		if config.plugins.PermanentEvent.enabled.value:
			if config.plugins.PermanentEvent.show_hide.value:
				list.append(_("Disable key 'long EXIT' show/nide"))
			else:
				list.append(_("Enable key 'long EXIT' show/nide"))
		self["list"].setList(list)



    def newConfig(self):
		pClock.dialog.hide()
		pClock.ColorAnalog()
		if pClock.dialog is None:
			pClock.gotSession(self.session)

					
    def okClicked(self):
		sel = self["list"].getCurrent()
		if pClock.dialog is None:
			pClock.gotSession(self.session)
		if sel == _("Deactivate Permanent Event") or sel == _("Activate Permanent Event"):
			pClock.changeVisibility()
			self.showMenu()
		if sel == _("Change Permanent Event position") :
			pClock.dialog.hide()
			self.session.openWithCallback(self.positionerCallback, PermanentEventPositioner)
		if sel == _("Show analog clock") or sel == _("Show digital clock"):
			if pClock.dialog is not None:
				pClock.dialog.hide()
				pClock.changeAnalog()
				self.showMenu()
				if pClock.dialog is None:
					pClock.gotSession(self.session)
		if sel == _("Disable key 'long EXIT' show/nide"):
			if pClock.dialog is not None:
				pClock.changeKey()
				self.showMenu()
				pClock.unload_key()
		if sel == _("Enable key 'long EXIT' show/nide"):
			if pClock.dialog is not None:
				pClock.changeKey()
				self.showMenu()
				pClock.start_key()
		if sel == _("Change analog clock"):
			self.colorClock()
			
    def colorClock(self):
		list = [
			(_("maggy-style"), self.skins1),
			(_("maggy-breitling"), self.skins2),
			(_("maggy-tissot"), self.skins3),
			(_("maggy-ferrari"), self.skins4),
			(_("maggy-rolex"), self.skins5),
			(_("maggy-grand carrera"), self.skins6),
			(_("maggy-style2"), self.skins7),
			(_("maggy-style3"), self.skins8),
			(_("grey-metallic"), self.skins9),
			(_("black-yellow"), self.skins10),
			(_("atile-style"), self.skins11),
			(_("maggy-tron"), self.skins12),
			(_("maggy-globe"), self.skins13),
			(_("maggy-black"), self.skins14),
			(_("maggy-black-gold"), self.skins15),
			(_("maggy-omega"), self.skins16),
			(_("maggy-gt"), self.skins17),
			(_("silver-red"), self.skins18),
			(_("hsv"), self.skins19),
			(_("fcb"), self.skins20),
			(_("bvb"), self.skins21),
			(_("christmas"), self.skins22),
			(_("carrera"), self.skins23),
			(_("porsche"), self.skins24),
			(_("nixon"), self.skins25),
			(_("luminor"), self.skins26),
			(_("blue"), self.skins27),
			(_("d-g"), self.skins28),
			(_("g-shock"), self.skins29),
			(_("maggy-carbon"), self.skins30),
		]
		self.session.openWithCallback(
			self.menuCallback,
			ChoiceBox,
			title= _("Choice clock color:"),
			list = list,
		)

    def menuCallback(self, ret = None):
		ret and ret[1]()

    def positionerCallback(self, callback=None):
		pClock.showHide()

    def skins1(self):
		config.plugins.PermanentEvent.color_analog.value = "1"
		self.newConfig()
		
    def skins2(self):
		config.plugins.PermanentEvent.color_analog.value = "2"
		self.newConfig()

    def skins3(self):
		config.plugins.PermanentEvent.color_analog.value = "3"
		self.newConfig()

    def skins4(self):
		config.plugins.PermanentEvent.color_analog.value = "4"
		self.newConfig()

    def skins5(self):
		config.plugins.PermanentEvent.color_analog.value = "5"
		self.newConfig()
		
    def skins6(self):
		config.plugins.PermanentEvent.color_analog.value = "6"
		self.newConfig()
		
    def skins7(self):
		config.plugins.PermanentEvent.color_analog.value = "7"
		self.newConfig()
		
    def skins8(self):
		config.plugins.PermanentEvent.color_analog.value = "8"
		self.newConfig()
		
    def skins9(self):
		config.plugins.PermanentEvent.color_analog.value = "9"
		self.newConfig()
		
    def skins10(self):
		config.plugins.PermanentEvent.color_analog.value = "10"
		self.newConfig()
	
    def skins11(self):
		config.plugins.PermanentEvent.color_analog.value = "11"
		self.newConfig()
	
    def skins12(self):
		config.plugins.PermanentEvent.color_analog.value = "12"
		self.newConfig()
		
    def skins13(self):
		config.plugins.PermanentEvent.color_analog.value = "13"
		self.newConfig()
		
    def skins14(self):
		config.plugins.PermanentEvent.color_analog.value = "14"
		self.newConfig()
		
    def skins15(self):
		config.plugins.PermanentEvent.color_analog.value = "15"
		self.newConfig()
	
    def skins16(self):
		config.plugins.PermanentEvent.color_analog.value = "16"
		self.newConfig()
		
    def skins17(self):
		config.plugins.PermanentEvent.color_analog.value = "17"
		self.newConfig()
		
    def skins18(self):
		config.plugins.PermanentEvent.color_analog.value = "18"
		self.newConfig()
	
    def skins19(self):
		config.plugins.PermanentEvent.color_analog.value = "19"
		self.newConfig()
		
    def skins20(self):
		config.plugins.PermanentEvent.color_analog.value = "20"
		self.newConfig()
	
    def skins21(self):
		config.plugins.PermanentEvent.color_analog.value = "21"
		self.newConfig()
		
    def skins22(self):
		config.plugins.PermanentEvent.color_analog.value = "22"
		self.newConfig()
	
    def skins23(self):
		config.plugins.PermanentEvent.color_analog.value = "23"
		self.newConfig()
		
    def skins24(self):
		config.plugins.PermanentEvent.color_analog.value = "24"
		self.newConfig()
		
    def skins25(self):
		config.plugins.PermanentEvent.color_analog.value = "25"
		self.newConfig()
	
    def skins26(self):
		config.plugins.PermanentEvent.color_analog.value = "26"
		self.newConfig()
		
    def skins27(self):
		config.plugins.PermanentEvent.color_analog.value = "27"
		self.newConfig()
		
    def skins28(self):
		config.plugins.PermanentEvent.color_analog.value = "28"
		self.newConfig()
		
    def skins29(self):
		config.plugins.PermanentEvent.color_analog.value = "29"
		self.newConfig()
		
    def skins30(self):
		config.plugins.PermanentEvent.color_analog.value = "30"
		self.newConfig()
##############################################################################

def sessionstart(reason, **kwargs):
	if reason == 0:
		pClock.gotSession(kwargs["session"])

def startConfig(session, **kwargs):
	session.open(PermanentEventMenu)

def main(menuid):
	if menuid != "system": 
		return [ ]
	return [(_("Permanent Event"), startConfig, "permanent_event", None)]

##############################################################################

def Plugins(**kwargs):
	return [
		PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart),
		PluginDescriptor(name=_("Permanent Event"), description=_("Shows the clock permanent on the screen"), where=PluginDescriptor.WHERE_MENU, fnc=main)]
