# Embedded file name: plugin.py
from Components.ScrollLabel import ScrollLabel
from Components.Pixmap import Pixmap
from enigma import eListboxPythonMultiContent, getDesktop, gFont, loadPNG, eTimer
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Tools.LoadPixmap import LoadPixmap
from Components.ActionMap import ActionMap, NumberActionMap
from Tools.Directories import fileExists
from Screens.Screen import Screen
from Components.Button import Button
from Components.Label import Label
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Screens.MessageBox import MessageBox
from Components.Sources.StaticText import StaticText
from Plugins.Plugin import PluginDescriptor
from math import degrees, radians, atan, asin, acos, cos, sin, tan
from datetime import date, datetime
from datetime import  timedelta, time
from time import strptime
import xml.dom.minidom
import os
from enigma import eTimer, quitMainloop, eListbox, ePoint, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_VALIGN_CENTER, eListboxPythonMultiContent, eListbox, gFont, getDesktop, ePicLoad, eServiceCenter, iServiceInformation, eServiceReference, iSeekableService, iServiceInformation, iPlayableService, iPlayableServicePtr
from time import strftime, localtime
from Screens.Standby import TryQuitMainloop
session = None
from Screens.Console import Console
from Screens.InfoBarGenerics import InfoBarShowHide, InfoBarSeek, InfoBarNotifications, InfoBarServiceNotifications
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from Components.ConfigList import ConfigList, ConfigListScreen
from Components.config import config, ConfigDirectory, ConfigSubsection, ConfigSubList, ConfigEnableDisable, ConfigNumber, ConfigText, ConfigSelection, ConfigYesNo, ConfigPassword, getConfigListEntry, configfile
config.plugins.Cpraytime2 = ConfigSubsection()
config.plugins.Cpraytime = ConfigSubsection()
config.plugins.Cpraytime2.notification = ConfigSelection(default='disabled', choices=[('disabled', _('Disabled')), ('enabled', _('Enabled'))])
config.plugins.Cpraytime.calculation = ConfigSelection(default='UmmAlQuraUniv', choices=[('MuslimWorldLeague', _('Muslim World League')),
 ('UmmAlQuraUniv', _('Umm Al-Qura')),
 ('IslamicSocietyOfNorthAmerica', _('North America')),
 ('UnivOfIslamicSciencesKarachi', _('University Of Islamic Sciences Karachi')),
 ('EgyptianGeneralAuthorityOfSurvey', _('Egyptian General Authority of Survey'))])
config.plugins.Cpraytime.mathhab = ConfigSelection(default='Standard', choices=[('Standard', _('Standard')), ('Hanafi', _('Hanafi'))])
config.plugins.Cpraytime.season = ConfigSelection(default='Winter', choices=[('Winter', _('No daylight saving timing')), ('SummurSaving', _('Daylight saving timing'))])
config.plugins.Cpraytime.Timeformat = ConfigSelection(default='24', choices=[('ampm', _('AM/PM')), ('24', _('24HR'))])
pluginfolder = '/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/'
dwidth = getDesktop(0).size().width()

class AthanTimesStream(Screen, InfoBarNotifications):
    STATE_IDLE = 0
    STATE_PLAYING = 1
    STATE_PAUSED = 2
    ENABLE_RESUME_SUPPORT = True
    ALLOW_SUSPEND = True
    PLAYER_STOPS = 3
    skinfhd = '<screen name="AthanTimesStream" flags="wfNoBorder" position="0,0" size="1920,1080" title="AthanTimesStream" backgroundColor="transparent"><widget source="session.CurrentService" render="Label" position="193,826" size="1450,250" font="Regular; 35" backgroundColor="#263c59" shadowColor="#1d354c" shadowOffset="-1,-1" transparent="1" zPosition="1" halign="center"><convert type="ServiceName">Name</convert></widget><widget source="global.CurrentTime" render="Label" position="1398,719" size="250,100" font="Regular; 28" halign="center" backgroundColor="black" transparent="1"><convert type="ClockToText">Format:%d.%m.%Y</convert></widget><ePixmap position="388,217" size="1000,600" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images/Demar.png" zPosition="-1" transparent="1" alphatest="blend" /><eLabel text="\xd9\x85\xd9\x88\xd8\xa7\xd9\x82\xd9\x8a\xd8\xaa \xd8\xa7\xd9\x84\xd8\xb5\xd9\x84\xd8\xa7\xd8\xa9" position="388,74" size="1000,68" font="Regular; 35" halign="center" transparent="0" foregroundColor="white" backgroundColor="#11f4b" zPosition="3" /><eLabel text="Athan Times" position="388,148" size="1000,68" font="Regular; 35" halign="center" transparent="0" foregroundColor="white" backgroundColor="#11f4b" zPosition="3" /></screen>'
    skinhd = '<screen name="AthanTimesStream" flags="wfNoBorder" position="0,0" size="1280,720" title="LiveSoccerStream" backgroundColor="transparent"><widget source="session.CurrentService" render="Label" position="-2,616" size="1280,100" font="Regular; 20" backgroundColor="#263c59" shadowColor="#1d354c" shadowOffset="-1,-1" transparent="1" zPosition="1" halign="center"><convert type="ServiceName">Name</convert></widget><widget source="global.CurrentTime" render="Label" position="11,509" size="150,100" font="Regular; 24" halign="center" backgroundColor="black" transparent="1"><convert type="ClockToText">Format:%d.%m.%Y</convert></widget><ePixmap position="165,15" size="1000,600" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images/Demar.png" zPosition="-1" transparent="1" alphatest="blend" /></screen>'

    def __init__(self, session, service):
        Screen.__init__(self, session)
        if dwidth == 1280:
            self.skin = AthanTimesStream.skinhd
        else:
            self.skin = AthanTimesStream.skinfhd
        InfoBarNotifications.__init__(self)
        self.session = session
        self.service = service
        self.screen_timeout = 1000
        self.__event_tracker = ServiceEventTracker(screen=self, eventmap={iPlayableService.evSeekableStatusChanged: self.__seekableStatusChanged,
         iPlayableService.evStart: self.__serviceStarted,
         iPlayableService.evEOF: self.__evEOF})
        self['actions'] = ActionMap(['OkCancelActions',
         'InfobarSeekActions',
         'ColorActions',
         'MediaPlayerActions',
         'MovieSelectionActions'], {'ok': self.leavePlayer,
         'cancel': self.leavePlayer,
         'stop': self.leavePlayer}, -2)
        self['pauseplay'] = Label(_('Play'))
        self.hidetimer = eTimer()
        self.repeter = True
        self.state = self.STATE_PLAYING
        self.onPlayStateChanged = []
        self.play()
        self.onClose.append(self.__onClose)

    def __onClose(self):
        self.session.nav.stopService()

    def __evEOF(self):
        self.STATE_PLAYING = True
        self.state = self.STATE_PLAYING
        self.session.nav.playService(self.service)
        if self.session.nav.stopService():
            self.state = self.STATE_PLAYING
            self.session.nav.playService(self.service)
        else:
            self.leavePlayer()

    def __setHideTimer(self):
        self.hidetimer.start(self.screen_timeout)

    def ok(self):
        self.leavePlayer()

    def playNextFile(self):
        self.session.open(MessageBox, 'only to watch not play Next and Prev File', MessageBox.TYPE_INFO)

    def playPrevFile(self):
        self.session.open(MessageBox, 'only to watch not play Next and Prev File', MessageBox.TYPE_INFO)

    def playService(self, newservice):
        if self.state == self.STATE_IDLE:
            self.play()
        self.service = newservice

    def play(self):
        self.state = self.STATE_PLAYING
        self['pauseplay'].setText('PLAY')
        self.session.nav.playService(self.service)
        self.__evEOF

    def __seekableStatusChanged(self):
        service = self.session.nav.getCurrentService()
        if service is not None:
            seek = service.seek()
            if seek is None or not seek.isCurrentlySeekable():
                self.setSeekState(self.STATE_PLAYING)
                self.__evEOF
        return

    def __serviceStarted(self):
        self.state = self.STATE_PLAYING
        self.__evEOF

    def setSeekState(self, wantstate):
        print 'setSeekState'
        if wantstate == self.STATE_PAUSED:
            print 'trying to switch to Pause- state:', self.STATE_PAUSED
        elif wantstate == self.STATE_PLAYING:
            print 'trying to switch to playing- state:', self.STATE_PLAYING
        service = self.session.nav.getCurrentService()
        if service is None:
            print 'No Service found'
            return False
        else:
            pauseable = service.pause()
            if pauseable is None:
                print 'not pauseable.'
                self.state = self.STATE_PLAYING
            if pauseable is not None:
                print 'service is pausable'
                if wantstate == self.STATE_PAUSED:
                    print 'WANT TO PAUSE'
                    pauseable.pause()
                    self.state = self.STATE_PAUSED
                    if not self.shown:
                        self.hidetimer.stop()
                        self.show()
                elif wantstate == self.STATE_PLAYING:
                    print 'WANT TO PLAY'
                    pauseable.unpause()
                    self.state = self.STATE_PLAYING
                    if self.shown:
                        self.__setHideTimer()
            for c in self.onPlayStateChanged:
                c(self.state)

            return True
            return

    def handleLeave(self):
        self.close()

    def leavePlayer(self):
        self.close()


def openfile():
    try:
        fp = open(pluginfolder + 'favcity', 'r')
        line = fp.read()
        fp.close()
        return line
    except:
        cname = 'none'
        return cname


def wfile(st):
    ptimesfile = pluginfolder + 'prayertimes'
    fp = open(ptimesfile, 'w')
    fp.write(st)
    fp.close()


def checkhothour():
    ptimesfile = pluginfolder + 'prayertimes'
    ptfile = open(ptimesfile, 'r')
    data = ptfile.readlines()
    ptfile.close()
    country = data[1]
    city = data[2]
    fajr_time = data[3]
    shrouk_time = data[4]
    zuhr_time = data[5]
    asr_time = data[6]
    maghrb_time = data[7]
    esha_time = data[8]
    fajr_time = fajr_time.strip()
    zuhr_time = zuhr_time.strip()
    asr_time = asr_time.strip()
    maghrb_time = maghrb_time.strip()
    esha_time = esha_time.strip()
    list = []
    list.append(fajr_time[0:2])
    list.append(zuhr_time[0:2])
    list.append(asr_time[0:2])
    list.append(maghrb_time[0:2])
    list.append(esha_time[0:2])
    now = datetime.now
    hr = str(now.hour)
    minute = str(now.minute)
    if len(hr) == 1:
        hr = '0' + hr
    if len(minute) == 1:
        minute = '0' + minute
    if minute == '00':
        if hr in list:
            return True
        else:
            return False
    return False


class PrayerTimesAboutScreen(Screen):
    if dwidth == 1280:
        skin = '\n\t                       <screen position="center,center" size="550,460" title="PrayerTimes" >\n\t\t                    <widget name="text" position="0,210" size="550,250" font="Regular;20" />\n\t\t                     <ePixmap position="100,0" zPosition="4" size="343,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images/tunisiasat.png" transparent="1" alphatest="on" />\n                              </screen>'
    else:
        skin = '\n                 <screen position="9,11" size="753,849" title="PrayerTimes" flags="wfNoBorder" backgroundColor="transparent">\n                  <widget name="text" position="0,214" size="750,271" font="Regular; 25" zPosition="5" backgroundColor="black" />\n                   <ePixmap position="2,0" zPosition="2" size="750,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images1/tunisiasat.png" transparent="1" alphatest="blend" />\n                    <ePixmap position="1,486" zPosition="2" size="750,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images1/hadith2.png" transparent="1" alphatest="blend" />\n                    </screen>'

    def __init__(self, session):
        Screen.__init__(self, session)
        info = '\nPrayerTimes version 1.5-\ncoder-Mahmoud Faraj-Tunisiasat\n --------------------------- \n Tunisiasat PrayerTimes work group\n Tounsi9_4  Sami73  Sangoku  slim.k mFaraj57\n Tunisia-sat.com \n --------------------------- \n                            WWW.TUNISIA-SAT.COM'
        self['ButtonYellow'] = Pixmap()
        self['ButtonYellowtext'] = Button(_('Change city'))
        self['text'] = ScrollLabel(info)
        self['actions'] = ActionMap(['SetupActions'], {'ok': self.close,
         'cancel': self.close}, -1)


class CpraytimeSetup(Screen, ConfigListScreen):
    if dwidth == 1280:
        skin = '\n\t\t                   <screen position="center,center" size="560,400" title="Prayer Times Setup" >\n\t                        <ePixmap position="0,0" size="560,400" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images/bg2.png" alphatest="blend" transparent="1" backgroundColor="transparent"/>\t\t\n\t\t\t                 <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/ddbuttons/red25.png" position="30,10" zPosition="0" size="250,40" transparent="1" alphatest="on" />\n\t\t\t                  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/ddbuttons/green25.png" position="280,10" zPosition="0" size="250,40" transparent="1" alphatest="on" />\n\t\t\t                   <widget render="Label" source="key_red" position="30,10" size="250,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />\n\t\t\t                    <widget render="Label" source="key_green" position="280,10" size="250,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />\n\t\t\t                     <widget name="config" position="10,60" size="550,330" scrollbarMode="showOnDemand" zPosition="2" transparent="1" />\n                                  </screen>'
    else:
        skin = '\n\t\t         <screen name="CpraytimeSetup" position="9,11" size="960,675" title="Prayer Times Setup" flags="wfNoBorder" backgroundColor="black">\n                  <ePixmap position="9,11" size="960,675" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images1/bg2.png" alphatest="blend" transparent="0" backgroundColor="transparent" zPosition="1" />\t\t\n                   <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/ddbuttons/red25.png" position="29,633" zPosition="2" size="250,40" transparent="1" alphatest="on" />\n                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/ddbuttons/green25.png" position="668,633" zPosition="2" size="250,40" transparent="1" alphatest="on" />\n                     <widget render="Label" source="key_red" position="29,633" size="250,40" zPosition="5" valign="center" halign="center" backgroundColor="black" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />\n                      <widget render="Label" source="key_green" position="668,633" size="250,40" zPosition="5" valign="center" halign="center" backgroundColor="black" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />\n                       <widget name="config" position="29,103" size="887,473" itemHeight="43" scrollbarMode="showOnDemand" zPosition="2" transparent="1" font="Regular; 35" backgroundColor="black" />\n                        <eLabel text="Prayer Times Setup" position="31,29" size="830,65" font="Regular; 42" halign="center" transparent="0" foregroundColor="white" backgroundColor="#3a0000" zPosition="2" />\n                         </screen>'

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self['key_red'] = StaticText(_('Cancel'))
        self['key_green'] = StaticText(_('OK'))
        self.session = session
        self.oldvalue = config.plugins.Cpraytime2.notification.value
        self.list = []
        self.list.append(getConfigListEntry(_('Notify athan time on screen:'), config.plugins.Cpraytime2.notification))
        self.list.append(getConfigListEntry(_('Calculation method:'), config.plugins.Cpraytime.calculation))
        self.list.append(getConfigListEntry(_('Mathhab:'), config.plugins.Cpraytime.mathhab))
        self.list.append(getConfigListEntry(_('Daylight saving time'), config.plugins.Cpraytime.season))
        ConfigListScreen.__init__(self, self.list, session)
        self['setupActions'] = ActionMap(['SetupActions', 'ColorActions'], {'green': self.keySave,
         'cancel': self.keyClose,
         'ok': self.keySave}, -2)

    def keySave(self):
        for x in self['config'].list:
            x[1].save()

        configfile.save()
        self.info = 'Restart plugin to load new settings'
        if not config.plugins.Cpraytime2.notification.value == self.oldvalue:
            self.session.openWithCallback(self.restartenigma, MessageBox, _('Restart enigma2 to load new settings?'), MessageBox.TYPE_YESNO)
            return
        self.close()

        def restartplugin(self, result):
            Praytime.close()
            self.close()

    def keyClose(self):
        for x in self['config'].list:
            x[1].cancel()

        self.close()

    def restartenigma(self, result):
        if result:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()


class PrayerTimescontinent(Screen):
    skin1 = '\n\t\t                      <screen position="center,center" size="560,475" title="PrayerTimes-select continent">\n                               <ePixmap position="0,0" size="560,475" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images/bg2.png" alphatest="blend" transparent="1" backgroundColor="transparent"/>\t\t\t\t\t\n                                <widget name="countrymenu" position="0,50" size="560,475" scrollbarMode="showOnDemand" zPosition="2" transparent="1" />\n                                 </screen>'
    skin2 = '\n\t\t             <screen position="9,11" size="1260,1269" title="PrayerTimes-select continent" backgroundColor="transparent" flags="wfNoBorder">\n                      <ePixmap position="9,11" size="960,675" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images1/bg2.png" alphatest="blend" transparent="0" backgroundColor="transparent" zPosition="1" />\n                       <widget name="countrymenu" position="29,103" size="887,473" scrollbarMode="showOnDemand" zPosition="2" transparent="1" backgroundColor="black" font="Regular; 25" />\n                        <eLabel text="PrayerTimes-select continent" position="31,29" size="830,65" font="Regular; 42" halign="center" transparent="0" foregroundColor="white" backgroundColor="#3a0000" zPosition="2" />\n                         <eLabel text="Choose your country" position="9,633" size="960,25" font="Regular; 22" halign="center" transparent="0" foregroundColor="white" backgroundColor="#3a0000" zPosition="3" />\n                          <eLabel position="9,11" size="960,675" backgroundColor="black" />\n                           <ePixmap position="290,696" size="300,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images1/allah.png" alphatest="blend" transparent="0" backgroundColor="transparent" zPosition="1" />\n                            </screen>'

    def __init__(self, session):
        if dwidth == 1280:
            self.skin = PrayerTimescontinent.skin1
        else:
            self.skin = PrayerTimescontinent.skin2
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['SetupActions', 'ColorActions'], {'ok': self.selContenant,
         'cancel': self.close}, -2)
        self.list = MenuList([])
        self['countrymenu'] = self.list
        list1 = []
        list1.append('Africa(A-L)')
        list1.append('Africa(M-Z)')
        list1.append('Asia-Eurasia(A-L)')
        list1.append('Asia-Eurasia(M-Z)')
        list1.append('Australia-NewZealand')
        list1.append('Europe(A-L)')
        list1.append('Europe(M-Z)')
        list1.append('North-America(Bermuda-Canada-Mexico)')
        list1.append('North-America(USA-Province(A-L))')
        list1.append('North-America(USA-Province(M-Z))')
        list1.append('South-Central-America-Caribbean')
        self.list.setList(list1)

    def selContenant(self):
        selection = str(self['countrymenu'].getCurrent())
        self.session.open(PrayerTimesCountryscrn, selection)


class PrayerTimesCountryscrn(Screen):
    if dwidth == 1280:
        skin = '\n\t\t          <screen position="center,center" size="560,475" title="PrayerTimes-select country">\n\t                <ePixmap position="0,0" size="560,475" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images/bg2.png" alphatest="blend" transparent="1" backgroundColor="transparent"/>\t\t\t\n                \t <widget name="menu" position="10,0" size="540,475" scrollbarMode="showOnDemand" transparent="1" zPosition="2" />\n\t\t\t          <widget name="info" position="130,50" zPosition="4" size="300,300" font="Regular;24" foregroundColor="#ffffff" transparent="1" halign="center" valign="center" /> \n\t\t               </screen>'
    else:
        skin = '\n\t\t            <screen name="PrayerTimesCountryscrn" position="9,11" size="960,999" title="PrayerTimes-select country" backgroundColor="transparent" flags="wfNoBorder">\n                     <ePixmap position="9,11" size="960,675" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images1/bg2.png" alphatest="blend" transparent="0" backgroundColor="transparent" zPosition="1" />\n                      <widget name="menu" position="29,103" itemHeight="43" size="887,473" font="Regular; 25" scrollbarMode="showOnDemand" transparent="1" zPosition="2" />\n                       <widget name="info" position="29,279" zPosition="4" size="887,95" font="Regular; 50" transparent="1" halign="center" valign="center" foregroundColor="#3a0000" backgroundColor="black" />\n                        <eLabel text="PrayerTimes-select continent" position="31,29" size="830,65" font="Regular; 42" halign="center" transparent="0" foregroundColor="white" backgroundColor="#3a0000" zPosition="2" />\n                         <eLabel text="Choose your country" position="9,583" size="960,25" font="Regular; 22" halign="center" transparent="0" foregroundColor="white" backgroundColor="#3a0000" zPosition="3" />\n                          <eLabel position="9,11" size="960,675" backgroundColor="black" />\n                           <ePixmap position="290,696" size="300,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images1/mohamed.png" alphatest="blend" transparent="0" backgroundColor="transparent" zPosition="1" />\n                            </screen>'

    def __init__(self, session, selection = None):
        self.skin = PrayerTimesCountryscrn.skin
        Screen.__init__(self, session)
        self.selection = selection
        self.session = session
        self['menu'] = MenuList([])
        self['info'] = Label()
        self.downloading = False
        self['actions'] = ActionMap(['SetupActions'], {'ok': self.selContenant,
         'cancel': self.close}, -2)
        self['info'].setText('Loading countries ...please wait')
        self.timer = eTimer()
        self.timer.callback.append(self.loadCountries)
        self.timer.start(200, 1)

    def loadCountries(self):
        list = []
        xmlfile = '/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/countries/' + str(self.selection) + '.xml'
        if os.path.isfile(xmlfile):
            xmlparse = xml.dom.minidom.parse(xmlfile)
            for country in xmlparse.getElementsByTagName('country'):
                list.append(country.getAttribute('count').encode('utf8'))

            self.xmlparse = xmlparse
            self['info'].setText('')
            self['menu'].setList(list)
            self.downloading = True
        else:
            self['info'].setText('Error in loading contries')

    def selContenant(self):
        if self.downloading == True:
            selection = str(self['menu'].getCurrent())
            self.session.open(PrayerTimesSelectCountry, self.xmlparse, selection)


class PrayerTimesSelectCountry(Screen):
    if dwidth == 1280:
        skin = '\n\t\t                 <screen position="center,center" size="560,500" title="PrayerTimes-select city">\n\t                      <ePixmap position="0,0" size="560,500" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images/bg2.png" alphatest="blend" transparent="1" backgroundColor="transparent"/>\t\t\t\t\t\n                           <widget name="ButtonBluetext" position="270,0" size="230,40" valign="center" halign="left" zPosition="10" font="Regular;18" transparent="1" />\n\t\t\t                <widget name="ButtonBlue" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/ddbuttons/button_blue.png" position="250,10" zPosition="10" size="100,100" transparent="1" alphatest="on" />\n                             <widget name="mymenu" position="10,60" size="540,375" scrollbarMode="showOnDemand" transparent="1" zPosition="2" />\n\t\t\t\n\t\t                     </screen>'
    else:
        skin = '\n \t\t              <screen name="PrayerTimesSelectCountry" position="9,11" size="960,999" title="PrayerTimes-select city" backgroundColor="transparent" flags="wfNoBorder">\n                       <ePixmap position="9,11" size="960,675" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images1/bg2.png" alphatest="blend" transparent="0" backgroundColor="transparent" zPosition="1" />\n                        <widget name="ButtonBluetext" position="534,107" size="330,55" valign="center" halign="left" zPosition="10" font="Regular; 30" transparent="1" backgroundColor="black" />\n                         <widget name="ButtonBlue" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/ddbuttons/button_blue.png" position="485,128" zPosition="10" size="55,55" transparent="1" alphatest="on" />\n                          <widget name="mymenu" position="31,176" size="887,473" itemHeight="43" scrollbarMode="showOnDemand" transparent="1" zPosition="2" backgroundColor="black" font="Regular; 28" />\n                           <eLabel text="PrayerTimes-select city" position="31,29" size="830,65" font="Regular; 42" halign="center" transparent="0" foregroundColor="white" backgroundColor="#3a0000" zPosition="2" />\n                            <eLabel position="9,11" size="960,675" backgroundColor="black" />\n                             <ePixmap position="9,689" size="960,250" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images1/hadit.png" alphatest="blend" transparent="0" backgroundColor="transparent" zPosition="1" />\n                              </screen>'

    def __init__(self, session, xmlparse, selection):
        self.skin = PrayerTimesSelectCountry.skin
        Screen.__init__(self, session)
        self['ButtonBlue'] = Pixmap()
        self['ButtonBluetext'] = Label(_('Select city'))
        self.xmlparse = xmlparse
        self.selection = selection
        list = []
        for country in self.xmlparse.getElementsByTagName('country'):
            if str(country.getAttribute('count').encode('utf8')) == self.selection:
                for city in country.getElementsByTagName('city'):
                    list.append(city.getAttribute('name').encode('utf8'))

        list.sort()
        self['mymenu'] = MenuList(list)
        self['actions'] = ActionMap(['SetupActions', 'ColorActions'], {'blue': self.saveParameters,
         'ok': self.saveParameters,
         'cancel': self.close}, -2)

    def selCountry(self):
        selection_country = self['mymenu'].getCurrent()
        self.country = selection_country
        countryname = self.country
        for country in self.xmlparse.getElementsByTagName('country'):
            if str(country.getAttribute('count').encode('utf8')) == self.selection:
                for city in country.getElementsByTagName('city'):
                    if city.getAttribute('name').encode('utf8') == selection_country:
                        scity = city.getAttribute('name')
                        cityname = city.getAttribute('name').encode('utf8')
                        zone = str(city.getElementsByTagName('zone')[0].childNodes[0].data)
                        info = zone.split('$')
                        zone = str(info[0])
                        longitude = str(info[1])
                        latitude = str(info[2])
                        scountry = country.getAttribute('count').encode('utf8')
                        self.zone = zone
                        self.city = scity
                        cityname = scity
                        zonevalue = zone
                        longitudevalue = longitude
                        latitudevalue = latitude

    def saveParameters(self):
        selection_city = self['mymenu'].getCurrent()
        self.city = selection_city
        for country in self.xmlparse.getElementsByTagName('country'):
            if str(country.getAttribute('count').encode('utf8')) == self.selection:
                for city in country.getElementsByTagName('city'):
                    if city.getAttribute('name').encode('utf8') == selection_city:
                        cityname = selection_city
                        zone = str(city.getElementsByTagName('zone')[0].childNodes[0].data)
                        info = zone.split('$')
                        zone = str(info[0])
                        longitude = str(info[1])
                        latitude = str(info[2])
                        scountry = self.selection
                        countryname = scountry
                        self.zone = zone
                        self.city = cityname
                        self.country = countryname
                        zonevalue = zone
                        longitudevalue = longitude
                        latitudevalue = latitude
                        longitude = longitudevalue
                        countryname = countryname.replace(',', ' ')
                        cityname = cityname.replace(',', ' ')
                        self.citycode = countryname + ',' + cityname + ',' + zone + ',' + longitude + ',' + latitude

        try:
            cname = self.citycode
            fp = open(pluginfolder + 'favcity', 'w')
            fp.write(cname)
            fp.close
        except:
            pass

        self.session.open(MessageBox, _(self.city + ' saved'), MessageBox.TYPE_INFO, 2)


class Praytime(Screen):
    sz_w = getDesktop(0).size().width()
    if sz_w == 1280:
        skin = '\n\t\t               <screen position="center,center" size="660,500" title="PrayerTimes-v1.5">\n                        <!-- Clock -->\n\t                     <ePixmap position="0,0" size="660,500" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images/bg2.png" alphatest="blend" transparent="1" backgroundColor="transparent"/>\t\t        \n                          <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/ddbuttons/clock.png" position="320, 5" zPosition="2" size="14,14" transparent="1" alphatest="blend" />\n                           <widget source="global.CurrentTime" render="Label" position="340, 0" zPosition="2" transparent="1" size="150, 40" font="Regular; 24" foregroundColor="yellow" halign="left">\n                            <convert type="ClockToText"/>\n                             </widget>\n                              <widget name="myLabeld" position="490,0" size="170,30" font="Regular;24" halign="left" foregroundColor="yellow" zPosition="2" transparent="1" />\n\t\t\t                   <ePixmap position="0,40" size="660,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images/slider.png" alphatest="blend" transparent="1" backgroundColor="transparent"/>\n                                <widget name="myLabel" position="10,70" size="130,40" font="Regular;24" zPosition="2" transparent="1" />\n\t\t                         <widget name="myLabelf" position="140,70" size="230,40" font="Regular;24" zPosition="2" transparent="1" />\n                                  <widget name="myLabels" position="10,120" size="130,40" font="Regular;24" zPosition="2" transparent="1" />\n                                   <widget name="myLabelsd" position="140,120" size="230,40" font="Regular;24" zPosition="2" transparent="1" />\n\t\t\t                        <widget name="myLabelz" position="10,170" size="130,40" font="Regular;24" zPosition="2" transparent="1" />\n\t\t\t                         <widget name="myLabelzd" position="140,170" size="230,40" font="Regular;24" zPosition="2" transparent="1" />\n                                      <widget name="myLabela" position="10,220" size="130,40" font="Regular;24" zPosition="2" transparent="1" />\n\t\t\t                           <widget name="myLabelad" position="140,220" size="230,40" font="Regular;24" zPosition="2" transparent="1" />\n                                        <widget name="myLabelm" position="10,270" size="130,40" font="Regular;24" zPosition="2" transparent="1" />\n\t\t\t                             <widget name="myLabelmd" position="140,270" size="230,40" font="Regular;24" zPosition="2" transparent="1" />\n\t\t\t                              <widget name="myLabeli" position="10,320" size="130,40" font="Regular;24" zPosition="2" transparent="1" />\n\t\t\t                               <widget name="myLabelid" position="140,320" size="230,40" font="Regular;24" zPosition="2" transparent="1" />\n\t\t\t                                <ePixmap position="0,370" size="660,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images/slider.png" alphatest="blend" transparent="1" backgroundColor="transparent"/>\n\t\t\t                                 <widget name="myLabelc" position="0,0" size="320,30" font="Regular;24" zPosition="2" transparent="1" />\n\t\t\t\n\t\t\t\n \t\t                                      <widget name="mazheb" position="10,380" size="250,40" font="Regular;20" zPosition="2" transparent="1" foregroundColor="yellow" />\t\t\t\n\t\t                                       <widget name="calc" position="10,420" size="250,40" font="Regular;20" zPosition="2" transparent="1" foregroundColor="yellow" />\t\t\n         \t                                    <widget name="mazhebtext" position="260,380" size="400,40" font="Regular;20" zPosition="2" transparent="1" foregroundColor="yellow" />\t\t\t\n\t\t                                         <widget name="calctext" position="260,420" size="400,40" font="Regular;20" zPosition="2" transparent="1" foregroundColor="yellow" />\t\t\n\t\t\t                                      <ePixmap position="0,450" size="660,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images/slider.png" alphatest="blend" transparent="1" backgroundColor="transparent"/>                                   \n                                                   <widget name="ButtonGreentext" position="20,460" size="240,45" valign="center" halign="center" zPosition="2" font="Regular;18" transparent="1"   />\n\t\t\t                                        <widget name="ButtonGreen" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/ddbuttons/green25.png" position="20,460" zPosition="2" size="220,45" transparent="1" alphatest="on" />\n\t\t\t\n\t\t\t                                         <widget name="ButtonBluetext" position="250,460" size="200,45" valign="center" halign="center" zPosition="2" font="Regular;18" transparent="1"   />\n\t\t\t                                          <widget name="ButtonBlue" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/ddbuttons/blue25.png" position="230,460" zPosition="2" size="220,45" transparent="1" alphatest="on" />\n\t \t\t                                           <widget name="ButtonGreentext1" position="430,460" size="240,45" valign="center" halign="center" zPosition="2" font="Regular;18" transparent="1"   />\n\t\t\t                                            <widget name="ButtonGreen1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/ddbuttons/yellow25.png" position="430,460" zPosition="2" size="220,45" transparent="1" alphatest="on" />\n\t\t\n\n\t\t                                                 </screen>'
    else:
        skin = """<screen name="Praytime" position="center,50" size="960,999" title="PrayerTimes-v1.5" backgroundColor="transparent" flags="wfNoBorder">
  <!-- Clock -->
  <ePixmap position="-4,11" size="960,720" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images1/bg2.png" alphatest="blend" transparent="0" backgroundColor="transparent" zPosition="1" />
  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/ddbuttons/clock.png" position="519,105" zPosition="2" size="14,14" transparent="1" alphatest="blend" />
  <widget source="global.CurrentTime" render="Label" position="536,97" zPosition="2" transparent="1" size="150,30" font="Regular; 28" foregroundColor="yellow" halign="left" backgroundColor="black">
    <convert type="ClockToText" />
  </widget>
  <widget name="myLabeld" position="691,97" size="170,30" font="Regular; 28" halign="left" foregroundColor="yellow" zPosition="2" transparent="1" backgroundColor="black" />
  <ePixmap position="9,131" size="960,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images1/slider.png" alphatest="blend" transparent="1" backgroundColor="transparent" zPosition="3" />
  <widget name="myLabel" position="123,139" size="250,40" font="Regular; 32" zPosition="2" transparent="1" backgroundColor="black" />
  <widget name="myLabelf" position="575,138" size="250,40" font="Regular; 32" zPosition="2" transparent="1" backgroundColor="black" />
  <widget name="myLabels" position="122,187" size="250,40" font="Regular; 32" zPosition="2" transparent="1" backgroundColor="black" />
  <widget name="myLabelsd" position="575,185" size="250,40" font="Regular; 32" zPosition="2" transparent="1" backgroundColor="black" />
  <widget name="myLabelz" position="121,233" size="250,40" font="Regular; 32" zPosition="2" transparent="1" backgroundColor="black" />
  <widget name="myLabelzd" position="573,235" size="250,40" font="Regular; 32" zPosition="2" transparent="1" backgroundColor="black" />
  <widget name="myLabela" position="123,281" size="250,40" font="Regular; 32" zPosition="2" transparent="1" backgroundColor="black" />
  <widget name="myLabelad" position="574,281" size="250,40" font="Regular; 32" zPosition="2" transparent="1" backgroundColor="black" />
  <widget name="myLabelm" position="126,327" size="250,40" font="Regular; 32" zPosition="2" transparent="1" backgroundColor="black" />
  <widget name="myLabelmd" position="574,332" size="250,40" font="Regular; 32" zPosition="2" transparent="1" backgroundColor="black" />
  <widget name="myLabeli" position="123,377" size="250,40" font="Regular; 32" zPosition="2" transparent="1" backgroundColor="black" />
  <widget name="myLabelid" position="575,379" size="250,40" font="Regular; 32" zPosition="2" transparent="1" backgroundColor="black" />
  <ePixmap position="9,424" size="960,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images1/slider.png" alphatest="blend" transparent="1" backgroundColor="transparent" zPosition="3" />
  <widget name="myLabelc" position="31,98" size="480,30" font="Regular; 30" zPosition="2" transparent="1" backgroundColor="black" />
  <widget name="mazheb" position="30,452" size="250,40" font="Regular; 28" zPosition="2" transparent="1" foregroundColor="yellow" backgroundColor="black" />
  <widget name="calc" position="31,512" size="450,40" font="Regular; 28" zPosition="2" transparent="1" foregroundColor="yellow" backgroundColor="black" />
  <widget name="mazhebtext" position="504,452" size="450,40" font="Regular; 28" zPosition="2" transparent="1" backgroundColor="black" />
  <widget name="calctext" position="504,512" size="450,40" font="Regular; 28" zPosition="2" transparent="1" backgroundColor="black" />
  <ePixmap position="9,567" size="960,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images1/slider.png" alphatest="blend" transparent="1" backgroundColor="transparent" zPosition="3" />
  <widget name="ButtonGreentext" position="24,675" size="240,45" valign="center" halign="center" zPosition="2" font="Regular; 20" transparent="1" backgroundColor="black" />
  <widget name="ButtonGreen" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/ddbuttons/green25.png" position="24,675" zPosition="2" size="240,45" transparent="1" alphatest="on" />
  <widget name="ButtonBluetext" position="351,675" size="240,45" valign="center" halign="center" zPosition="2" font="Regular; 20" transparent="1" backgroundColor="black" />
  <widget name="ButtonBlue" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/ddbuttons/blue25.png" position="351,675" zPosition="2" size="240,45" transparent="1" alphatest="on" />
  <widget name="ButtonGreentext1" position="694,675" size="240,45" valign="center" halign="center" zPosition="2" font="Regular; 20" transparent="1" backgroundColor="black" />
  <widget name="ButtonGreen1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/ddbuttons/yellow25.png" position="694,675" zPosition="2" size="240,45" transparent="1" alphatest="on" />
  <eLabel text="PrayerTimes-v1.5" position="31,29" size="830,65" font="Regular; 42" halign="center" transparent="0" foregroundColor="white" backgroundColor="un3a0000" zPosition="2" />
  <eLabel position="9,11" size="949,720" backgroundColor="black" />
  <widget name="myLabeldiff" position="24,587" size="476,65" font="Regular; 32" zPosition="3" transparent="0" />
  <widget name="" position="542,587" size="402,65" zPosition="2" />
  <eLabel name="mylab" text="\xD8\xA7\xD9\x84\xD9\x88\xD9\x82\xD8\xAA\x20\xD8\xA7\xD9\x84\xD9\x85\xD8\xAA\xD8\xA8\xD9\x82\xD9\x8A\x20\xD9\x84\xD9\x84\xD8\xB5\xD9\x84\xD8\xA7\xD8\xA9\x20\xD8\xA7\xD9\x84\xD8\xAA\xD8\xA7\xD9\x84\xD9\x8A\xD8\xA9 : " position="495,587" size="449,65" zPosition="2" font="Regular; 32" halign="center" />
</screen> """
    def __init__(self, session, args = None):
        self.session = session
        Screen.__init__(self, session)
        self['mazheb'] = Label(_('Mazheb:'))
        self['calc'] = Label(_('Calculation method:'))
        self['mazhebtext'] = Label(_(''))
        self['calctext'] = Label(_(''))
        self['ButtonGreen'] = Pixmap()
        self['ButtonGreentext'] = Label(_('Settings'))
        self['ButtonGreen1'] = Pixmap()
        self['ButtonGreentext1'] = Label(_('Change City'))
        self['ButtonBlue'] = Pixmap()
        self['ButtonBluetext'] = Label(_('About'))
        self['myLabel'] = Label('Fajr')
        self['myLabelf'] = Label('')
        self['myLabels'] = Label('Shrouk')
        self['myLabelsd'] = Label('')
        self['myLabelz'] = Label('Dhuhr')
        self['myLabelzd'] = Label('')
        self['myLabela'] = Label('Asr')
        self['myLabelad'] = Label('')
        self['myLabelm'] = Label('Maghrib')
        self['myLabelmd'] = Label('')
        self['myLabeli'] = Label('Isha')
        self['myLabelid'] = Label('')
        self['myLabeldiff'] = Label('')
        
        now = datetime.now()
        tdate2 = ' ' + now.strftime('%Y-%m-%d')
        self['myLabeld'] = Label(tdate2)
        self['myLabelc'] = Label('')
        self['actions'] = NumberActionMap(['SetupActions', 'ColorActions'], {'green': self.Showsettings,
         'yellow': self.Addcity,
         'blue': self.ShowAbout,
         'ok': self.close,
         'cancel': self.close}, -2)
        self.refresh()

    def refresh(self):
        getprayertimes()
        try:
            country = athans[0]
            city = athans[1]
            print '661:', city
            fajrtime = athans[2]
            shrouktime = athans[3]
            zuhrtime = athans[4]
            asrtime = athans[5]
            maghribtime = athans[6]
            ishatime = athans[7]
            noww=datetime.now()
            noww1=datetime.strftime(noww,'%H:%M:%S')
            noww=datetime.strptime(noww1,'%H:%M:%S')
            fajrtime12=datetime.strptime(fajrtime.strip(), '%H:%M:%S')
            zuhrtime12=datetime.strptime(zuhrtime.strip(), '%H:%M:%S')
            asrtime12=datetime.strptime(asrtime.strip(), '%H:%M:%S')
            maghribtime12=datetime.strptime(maghribtime.strip(), '%H:%M:%S')
            ishatime12=datetime.strptime(ishatime.strip(), '%H:%M:%S')
            liss=[fajrtime12,zuhrtime12,asrtime12,maghribtime12,ishatime12]
            for i in liss:
                if noww < i:
                    z=i - noww
                    hh=(datetime.min + z).time().hour
                    mm=(datetime.min + z).time().minute
                    ss=(datetime.min + z).time().second
                    diff= str(hh)+'  \xD8\xB3\xD8\xA7\xD8\xB9\xD8\xA9 , '+str(mm)+'\x20\xD8\xAF\xD9\x82\xD9\x8A\xD9\x82\xD8\xA9\x20\xD9\x88\x20'+str(ss)+' \x20\xD8\xAB\xD8\xA7\xD9\x86\xD9\x8A\xD8\xA9'
                    if 3<= hh <=10:
                        diff= str(hh)+'  \xD8\xB3\xD8\xA7\xD8\xB9\xD8\xA7\xD8\xAA , '+str(mm)+'\x20\xD8\xAF\xD9\x82\xD9\x8A\xD9\x82\xD8\xA9\x20\xD9\x88\x20'+str(ss)+' \x20\xD8\xAB\xD8\xA7\xD9\x86\xD9\x8A\xD8\xA9'
                    elif hh==2:
                        diff= '  \xD8\xB3\xD8\xA7\xD8\xB9\xD8\xAA\xD8\xA7\xD9\x86 , '+str(mm)+'\x20\xD8\xAF\xD9\x82\xD9\x8A\xD9\x82\xD8\xA9\x20\xD9\x88\x20'+str(ss)+' \x20\xD8\xAB\xD8\xA7\xD9\x86\xD9\x8A\xD8\xA9'
                    else:
                        diff= str(hh)+'  \xD8\xB3\xD8\xA7\xD8\xB9\xD8\xA9 , '+str(mm)+'\x20\xD8\xAF\xD9\x82\xD9\x8A\xD9\x82\xD8\xA9\x20\xD9\x88\x20'+str(ss)+' \x20\xD8\xAB\xD8\xA7\xD9\x86\xD9\x8A\xD8\xA9'
                    break
            if noww > liss[-1]:
                midnight = datetime.combine(noww + timedelta(days=1), time())
                midnight = datetime.combine(noww + timedelta(days=1), time())
                hh=(midnight - noww+liss[0]).hour
                mm=(midnight - noww+liss[0]).minute
                ss=(midnight - noww+liss[0]).second 
                if 3<= hh <=10:
                        diff= str(hh)+'  \xD8\xB3\xD8\xA7\xD8\xB9\xD8\xA7\xD8\xAA , '+str(mm)+'\x20\xD8\xAF\xD9\x82\xD9\x8A\xD9\x82\xD8\xA9\x20\xD9\x88\x20'+str(ss)+' \x20\xD8\xAB\xD8\xA7\xD9\x86\xD9\x8A\xD8\xA9'
                elif hh==2:
                        diff= '  \xD8\xB3\xD8\xA7\xD8\xB9\xD8\xAA\xD8\xA7\xD9\x86 , '+str(mm)+'\x20\xD8\xAF\xD9\x82\xD9\x8A\xD9\x82\xD8\xA9\x20\xD9\x88\x20'+str(ss)+' \x20\xD8\xAB\xD8\xA7\xD9\x86\xD9\x8A\xD8\xA9'
                else:
                        diff= str(hh)+'  \xD8\xB3\xD8\xA7\xD8\xB9\xD8\xA9 , '+str(mm)+'\x20\xD8\xAF\xD9\x82\xD9\x8A\xD9\x82\xD8\xA9\x20\xD9\x88\x20'+str(ss)+' \x20\xD8\xAB\xD8\xA7\xD9\x86\xD9\x8A\xD8\xA9'
            
        except:
            return

        self['myLabelc'].setText(country + ' -' + city)
        self['myLabelf'].setText(fajrtime)
        self['myLabelsd'].setText(shrouktime)
        self['myLabelzd'].setText(zuhrtime)
        self['myLabelad'].setText(asrtime)
        self['myLabelmd'].setText(maghribtime)
        self['myLabelid'].setText(ishatime)
        self['myLabeldiff'].setText(diff)
        calculation = config.plugins.Cpraytime.calculation.value
        mazheb = config.plugins.Cpraytime.mathhab.value
        self['mazhebtext'].setText(mazheb)
        self['calctext'].setText(calculation)

    def Showsettings(self):
        self.session.openWithCallback(self.refresh, CpraytimeSetup)

    def ShowAbout(self):
        self.session.open(PrayerTimesAboutScreen)

    def Addcity(self):
        self.session.openWithCallback(self.refresh, PrayerTimescontinent)


def remove_duplication(var):
    if var > 360:
        var /= 360
        var -= int(var)
        var *= 360
    return var


class Season(object):
    Winter, Summer = (0, 1)


class Calendar(object):
    UmmAlQuraUniv, EgyptianGeneralAuthorityOfSurvey, UnivOfIslamicSciencesKarachi, IslamicSocietyOfNorthAmerica, MuslimWorldLeague = range(5)


class Mazhab(object):
    Default, Hanafi = (0, 1)


def to_hrtime(var, isAM = False, tformat = False):
    """var: double -> human readable string of format "%I:%M:%S %p" """
    time = ''
    intvar = int(var)
    if isAM:
        if intvar % 12 and intvar % 12 < 12:
            zone = 'AM'
        else:
            zone = 'PM'
    else:
        zone = 'PM'
    if intvar > 12:
        if intvar == 24:
            time += str(12)
        else:
            time += str(intvar % 12)
    elif intvar % 12 == 12:
        time += str(intvar)
    else:
        time += str(intvar)
    if tformat == True:
        if zone == 'AM':
            hh = time
        else:
            hh = (int(time) + 12) % 24
        if hh == 0:
            hh = 12
        time = str(hh)
        time += ':'
        var -= intvar
        var *= 60
        minute = int(var)
        time += str(minute)
        time += ':'
        var -= int(var)
        var *= 60
        sec = int(var)
        time += str(sec)
        time += ' '
    else:
        time += ':'
        var -= intvar
        var *= 60
        minute = int(var)
        time += str(minute)
        time += ':'
        var -= int(var)
        var *= 60
        sec = int(var)
        time += str(sec)
        time += ' '
        time += zone
    return time


def as_pytime(string_to_parse, fmt = '%I:%M:%S %p'):
    """returns time.tm_struct by parsing string_to_parse."""
    return strptime(string_to_parse, fmt)


def as_pydatetime(d, ts):
    """returns a datetime object.
            d: date object
            ts: tm_struct
    """
    return datetime(year=d.year, month=d.month, day=d.day, hour=ts.tm_hour, minute=ts.tm_min, second=ts.tm_sec)


class Coordinate(object):

    def __init__(self, longitude, latitude, zone):
        """
            Describe a place by its longitude, latitude, and zone.
        """
        self.longitude = longitude
        self.latitude = latitude
        self.zone = zone


class Prayertime(object):

    def __init__(self, longitude, latitude, zone, cal = Calendar.MuslimWorldLeague, mazhab = Mazhab.Default, season = Season.Winter):
        if config.plugins.Cpraytime.calculation.value == 'UmmAlQuraUniv':
            cal = Calendar.UmmAlQuraUniv
        elif config.plugins.Cpraytime.calculation.value == 'EgyptianGeneralAuthorityOfSurvey':
            cal = Calendar.EgyptianGeneralAuthorityOfSurvey
        elif config.plugins.Cpraytime.calculation.value == 'MuslimWorldLeague':
            cal = Calendar.MuslimWorldLeague
        elif config.plugins.Cpraytime.calculation.value == 'IslamicSocietyOfNorthAmerica':
            cal = Calendar.IslamicSocietyOfNorthAmerica
        elif config.plugins.Cpraytime.calculation.value == 'UnivOfIslamicSciencesKarachi':
            cal = Calendar.UnivOfIslamicSciencesKarachi
        if config.plugins.Cpraytime.mathhab.value == 'Standard':
            mazhab = Mazhab.Default
        elif config.plugins.Cpraytime.mathhab.value == 'Hanafi':
            mazhab = Mazhab.Hanafi
        if config.plugins.Cpraytime.season.value == 'Winter':
            season = Season.Winter
        elif config.plugins.Cpraytime.season.value == 'SummurSaving':
            season = Season.Summer
        if config.plugins.Cpraytime.Timeformat.value == 'ampm':
            timeformat = False
        else:
            timeformat = True
        Extra = season
        longitudevalue = str(longitude)
        latitudevalue = str(latitude)
        zonevalue = str(zone)
        self.coordinate = Coordinate(longitude, latitude, zone)
        self.calendar = cal
        self.mazhab = mazhab
        self.season = season
        self._shrouk = None
        self._fajr = None
        self._zuhr = None
        self._asr = None
        self._maghrib = None
        self._isha = None
        self.dec = 0
        self.timeformat = timeformat
        return

    def shrouk_time(self):
        """Gets the time of shrouk."""
        fmt = to_hrtime(self._shrouk, True, self.timeformat)
        return fmt

    def fajr_time(self):
        """Gets the time of fajr."""
        fmt = to_hrtime(self._fajr, True, self.timeformat)
        return fmt

    def zuhr_time(self):
        """Gets the time of zuhr."""
        fmt = to_hrtime(self._zuhr, False, self.timeformat)
        return fmt

    def asr_time(self):
        """Gets the time of asr."""
        fmt = to_hrtime(self._asr, False, self.timeformat)
        return fmt

    def maghrib_time(self):
        """Gets the time of maghrib"""
        fmt = to_hrtime(self._maghrib, False, self.timeformat)
        return fmt

    def isha_time(self):
        """Gets the time of isha"""
        fmt = to_hrtime(self._isha, False, self.timeformat)
        return fmt

    def calculate(self):
        """Calculations of prayertimes."""
        now = datetime.now()
        year = now.year
        month = now.month
        day = now.day
        longitude = float(self.coordinate.longitude)
        latitude = float(self.coordinate.latitude)
        zone = float(self.coordinate.zone)
        julian_day = 367 * year - int((year + int((month + 9) / 12)) * 7 / 4) + int(275 * month / 9) + day - 730531.5
        sun_length = 280.461 + 0.9856474 * julian_day
        sun_length = remove_duplication(sun_length)
        middle_sun = 357.528 + 0.9856003 * julian_day
        middle_sun = remove_duplication(middle_sun)
        lamda = sun_length + 1.915 * sin(radians(middle_sun)) + 0.02 * sin(radians(2 * middle_sun))
        lamda = remove_duplication(lamda)
        obliquity = 23.439 - 4e-07 * julian_day
        alpha = degrees(atan(cos(radians(obliquity)) * tan(radians(lamda))))
        if 90 < lamda < 180:
            alpha += 180
        elif 100 < lamda < 360:
            alpha += 360
        ST = 100.46 + 0.985647352 * julian_day
        ST = remove_duplication(ST)
        self.dec = degrees(asin(sin(radians(obliquity)) * sin(radians(lamda))))
        noon = alpha - ST
        if noon < 0:
            noon += 360
        UTNoon = noon - longitude
        local_noon = UTNoon / 15 + zone
        zuhr = local_noon + 0.05
        maghrib = local_noon + self._equation(-0.8333) / 15 + 0.08333
        shrouk = local_noon - self._equation(-0.8333) / 15
        fajr_alt = 0
        isha_alt = 0
        if self.calendar == Calendar.UmmAlQuraUniv:
            fajr_alt = -19
        elif self.calendar == Calendar.EgyptianGeneralAuthorityOfSurvey:
            fajr_alt = -19.5
            isha_alt = -17.5
        elif self.calendar == Calendar.MuslimWorldLeague:
            fajr_alt = -18
            isha_alt = -17
        elif self.calendar == Calendar.IslamicSocietyOfNorthAmerica:
            fajr_alt = isha_alt = -15
        elif self.calendar == Calendar.UnivOfIslamicSciencesKarachi:
            fajr_alt = isha_alt = -18
        fajr = local_noon - self._equation(fajr_alt) / 15 + 0.05
        if self.error == True:
            fajr = shrouk - 2.3
        isha = local_noon + self._equation(isha_alt) / 15 + 0.05
        if self.error == True:
            isha = maghrib + 2.0
        if self.calendar == Calendar.UmmAlQuraUniv:
            isha = maghrib + 1.5
        asr_alt = 0
        if self.mazhab == Mazhab.Hanafi:
            asr_alt = 90 - degrees(atan(2 + tan(radians(abs(latitude - self.dec)))))
        else:
            asr_alt = 90 - degrees(atan(1 + tan(radians(abs(latitude - self.dec)))))
        asr = local_noon + self._equation(asr_alt) / 15 + 0.05
        if self.season == Season.Summer:
            fajr += 1
            shrouk += 1
            zuhr += 1
            asr += 1
            maghrib += 1
            isha += 1
        self._shrouk = shrouk
        self._fajr = fajr
        self._zuhr = zuhr
        self._asr = asr
        self._maghrib = maghrib
        self._isha = isha

    def _equation(self, alt):
        valsinradians = sin(radians(alt))
        valsinalt = sin(radians(self.dec))
        valsincolat = sin(radians(float(self.coordinate.latitude)))
        firstthree = valsinradians - valsinalt * valsincolat
        cosdes = cos(radians(self.dec))
        coslat = cos(radians(float(self.coordinate.latitude)))
        maqam = cosdes * coslat
        net = firstthree / maqam
        self.error = False
        if net < -1:
            self.error = True
            net = -1
        if net > 1:
            self.error = True
            net = 1
        val = acos(net)
        totalval = val
        return degrees(val)

    def report(self, country, city):
        """Simple report of all prayertimes."""
        global athans
        athans = []
        fajrtime = self.fajr_time()
        shrouktime = self.shrouk_time()
        zuhrtime = self.zuhr_time()
        asrtime = self.asr_time()
        maghribtime = self.maghrib_time()
        ishatime = self.isha_time()
        cit = str(city)
        count = str(country)
        athans.append(count)
        athans.append(cit)
        athans.append(fajrtime)
        athans.append(shrouktime)
        athans.append(zuhrtime)
        athans.append(asrtime)
        athans.append(maghribtime)
        athans.append(ishatime)
        extravalue = str(self.season)
        st = count + '\n' + cit + '\n' + self.fajr_time() + '\n' + self.shrouk_time() + '\n' + self.zuhr_time() + '\n' + self.asr_time() + '\n' + self.maghrib_time() + '\n' + self.isha_time()
        wfile(st)


if __name__ == '__main__':
    pt = Prayertime(46.7825, 24.6505, 3, 2009, 10, 5)
    pt.calculate()
    pt.report()
    self.close(None)

def main(session, **kwargs):
    session.open(prayertimesbootlogo)


def getprayertimes():
    try:
        cname = openfile()
        tup1 = cname.split(',')
        ccountry = tup1[0]
        ccity = tup1[1]
        print ccity
        czone = tup1[2]
        clongitude = tup1[3]
        clatitude = tup1[4]
        pt = Prayertime(clongitude, clatitude, czone)
        pt.calculate()
        pt.report(ccountry, ccity)
    except:
        pass


class prayertimesbootlogo(Screen):
    if dwidth == 1280:
        skin = '\n      \t<screen name="prayertimesbootlogo" position="center,center" size="640,520" title=""  flags="wfNoBorder" >\n                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images/logo.png" position="0,0" size="640,520"/>\n                \n\n \n\t\n         </screen>'
    else:
        skin = '\n      \t<screen name="prayertimesbootlogo" position="center,center" size="1050,950" title=""  flags="wfNoBorder" >\n                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images1/logo.png" position="0,0" size="1050,950"/>\n                \n\n \n\t\n         </screen>'

    def __init__(self, session):
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['SetupActions'], {'ok': self.disappear,
         'cancel': self.disappear}, -1)
        self.timer = eTimer()
        self.timer.callback.append(self.disappear)
        self.timer.start(8000, True)

    def disappear(self):
        self.session.openWithCallback(self.close, Praytime)


class athantimescr(Screen):
    if dwidth == 1280:
        skin = '<screen name="AthanTimesStream" flags="wfNoBorder" position="0,0" size="1920,1080" title="AthanTimesStream" backgroundColor="transparent"><widget source="session.CurrentService" render="Label" position="193,826" size="1450,250" font="Regular; 35" backgroundColor="#263c59" shadowColor="#1d354c" shadowOffset="-1,-1" transparent="1" zPosition="1" halign="center"><convert type="ServiceName">Name</convert></widget><widget source="global.CurrentTime" render="Label" position="13,9" size="250,100" font="Regular; 28" halign="left" backgroundColor="black" transparent="1"><convert type="ClockToText">Format:%d.%m.%Y</convert></widget><ePixmap position="388,217" size="1000,600" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images/Demar.png" zPosition="-1" transparent="1" alphatest="blend" /><eLabel text="\xd9\x85\xd9\x88\xd8\xa7\xd9\x82\xd9\x8a\xd8\xaa \xd8\xa7\xd9\x84\xd8\xb5\xd9\x84\xd8\xa7\xd8\xa9" position="388,74" size="1000,68" font="Regular; 35" halign="center" transparent="0" foregroundColor="white" backgroundColor="#11f4b" zPosition="3" /><eLabel text="Athan Times" position="388,148" size="1000,68" font="Regular; 35" halign="center" transparent="0" foregroundColor="white" backgroundColor="#11f4b" zPosition="3" /></screen>'
    else:
        skin = '<screen name="AthanTimesStream" flags="wfNoBorder" position="0,0" size="1280,720" title="LiveSoccerStream" backgroundColor="transparent"><widget source="session.CurrentService" render="Label" position="-2,616" size="1280,100" font="Regular; 20" backgroundColor="#263c59" shadowColor="#1d354c" shadowOffset="-1,-1" transparent="1" zPosition="1" halign="center"><convert type="ServiceName">Name</convert></widget><widget source="global.CurrentTime" render="Label" position="3,5" size="150,100" font="Regular; 24" halign="left" backgroundColor="black" transparent="1"><convert type="ClockToText">Format:%d.%m.%Y</convert></widget><ePixmap position="165,15" size="1000,600" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/images/Demar.png" zPosition="-1" transparent="1" alphatest="blend" /></screen>'

    def __init__(self, session, msg = None):
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['SetupActions'], {'ok': self.disappear,
         'cancel': self.disappear}, -1)
        self['info'] = Label(msg)
        self.timer = eTimer()
        self.timer.callback.append(self.disappear)
        self.timer.start(50000, True)

    def disappear(self):
        self.close()


def Plugins(**kwargs):
    return [PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc=autostart), PluginDescriptor(name='PrayerTimes', description='PrayerTimes-v1.5-Tunisiasat', where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main), PluginDescriptor(name='PrayerTimes', description='PrayerTimes-v1.5-Tunisiasat', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main,icon='prayertimes.png')]


class PrayerTimesBackgroundWorker(Screen):
    skin = '\n            <screen position="100,100" size="300,300" title="Mountie Plugin Menu" >\n            </screen>'

    def __init__(self, session, args = 0):
        self.skin = PrayerTimesBackgroundWorker.skin
        self.session = session
        Screen.__init__(self, session)
        self.menu = args
        self.session = session
        self.loop = eTimer()
        self.loop.callback.append(self.ExecTest)

    def stopTimer(self):
        self.loop.stop()

    def startTimer(self):
        self.loop.start(1, 1)

    def ExecTest(self):
        self.loop.stop()
        self.message = 'ExecutionTest11'
        self.DebugToLog()
        self.loop.start(3600000, 1)

    def DebugToLog(self):
        log_file = '/tmp/stayUPPlugin.log'
        try:
            f = open(log_file, 'r')
            log = f.read()
            f.close()
        except:
            log = ''

        now = datetime.now()
        timenow = str(now)
        getprayertimes()


def stoploop():
    StayLoop.stopTimer()


def autostart(reason, **kwargs):
    global session
    try:
        if config.plugins.Cpraytime2.notification.value == 'disabled':
            return
    except:
        pass

    if reason == 0:
        if openfile() == 'none':
            StayLoop.stopTimer
        else:
            StayLoop.startTimer()
    if reason == 0 and kwargs.has_key('session'):
        session = kwargs['session']
        session.open(DoPrayerTimes)


class DoPrayerTimes(Screen):
    skin = '\n            <screen position="100,100" size="300,300" title="paryertimes" >\n            </screen>'

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.minutecount = 30000
        self.TimerPrayerTimes = eTimer()
        self.TimerPrayerTimes.stop()
        self.TimerPrayerTimes.timeout.get().append(self.CheckPrayerTimes)
        self.TimerPrayerTimes.start(self.minutecount, True)

    def repeat(self, result = None):
        self.TimerPrayerTimes = eTimer()
        self.TimerPrayerTimes.stop()
        self.TimerPrayerTimes.timeout.get().append(self.CheckPrayerTimes)
        self.TimerPrayerTimes.start(self.minutecount, True)

    def CheckPrayerTimes(self):
        msg = comparetimes()
        now = datetime.now()
        if not msg == '':
            self.minutecount = 3600000
            self.initialservice = self.session.nav.getCurrentlyPlayingServiceReference()
            from enigma import eServiceReference
            url = '/usr/lib/enigma2/python/Plugins/Extensions/Prayertimes/Sound/ibrahim.mp3'
            ref = eServiceReference(4097, 0, url)
            ref.setName(msg)
            self.session.openWithCallback(self.backToIntialService, AthanTimesStream, ref)
        else:
            self.minutecount = 30000
            self.repeat()

    def backToIntialService(self):
        self.repeat()
        self.session.nav.stopService()
        self.session.nav.playService(self.initialservice)


def comparetimes():
    msgestr = ''
    try:
        now = datetime.now()
        hr = str(now.hour)
        minute = str(now.minute)
        if len(hr) == 1:
            hr = '0' + hr
        if len(minute) == 1:
            minute = '0' + minute
        hrminute = hr + minute
        hrminute = hrminute.replace(':', '')
        hrminute = hrminute.strip()
        ptimesfile = pluginfolder + 'prayertimes'
        ptfile = open(ptimesfile, 'r')
        data = ptfile.readlines()
        ptfile.close()
        country = data[0]
        city = data[1]
        fajr_time = data[2]
        fajr_time1 = data[2]
        f = []
        f = fajr_time.split(':')
        fhour = f[0]
        fminute = f[1]
        if len(fhour) == 1:
            fhour = '0' + fhour
        if len(fminute) == 1:
            fminute = '0' + fminute
        fajr_time = str(fhour) + str(fminute)
        zuhr_time = data[4]
        zuhr_time1 = data[4]
        f = []
        f = zuhr_time.split(':')
        fhour = f[0]
        fminute = f[1]
        if len(fhour) == 1:
            fhour = '0' + fhour
        if len(fminute) == 1:
            fminute = '0' + fminute
        zuhr_time = str(fhour) + str(fminute)
        asr_time = data[5]
        asr_time1 = data[5]
        f = []
        f = asr_time.split(':')
        fhour = f[0]
        fminute = f[1]
        if len(fhour) == 1:
            fhour = '0' + fhour
        if len(fminute) == 1:
            fminute = '0' + fminute
        asr_time = str(fhour) + str(fminute)
        #asr_time ='1720'
        maghrb_time = data[6]
        maghrb_time1 = data[6]
        f = []
        f = maghrb_time.split(':')
        fhour = f[0]
        fminute = f[1]
        if len(fhour) == 1:
            fhour = '0' + fhour
        if len(fminute) == 1:
            fminute = '0' + fminute
        maghrb_time = str(fhour) + str(fminute)
        esha_time = data[7]
        esha_time1 = data[7]
        f = []
        f = esha_time.split(':')
        fhour = f[0]
        fminute = f[1]
        if len(fhour) == 1:
            fhour = '0' + fhour
        if len(fminute) == 1:
            fminute = '0' + fminute
        esha_time = str(fhour) + str(fminute)
        fajr_time = fajr_time.strip()
        zuhr_time = zuhr_time.strip()
        asr_time = asr_time.strip()
        maghrb_time = maghrb_time.strip()
        esha_time = esha_time.strip()
        if hrminute == fajr_time:
            msgestr = '\n' + ' \xd8\xad\xd8\xa7\xd9\x86 \xd9\x85\xd9\x88\xd8\xb9\xd8\xaf \xd8\xb5\xd9\x84\xd8\xa7\xd8\xa9 \xd8\xa7\xd9\x84\xd9\x81\xd8\xac\xd8\xb1 ' + fajr_time1 + '  \xd8\xad\xd8\xb3\xd8\xa8 \xd8\xaa\xd9\x88\xd9\x82\xd9\x8a\xd8\xaa  ' + city + "  It's Now Fajr  "
        if hrminute == zuhr_time:
            msgestr = '\n' + ' \xd8\xad\xd8\xa7\xd9\x86 \xd9\x85\xd9\x88\xd8\xb9\xd8\xaf \xd8\xb5\xd9\x84\xd8\xa7\xd8\xa9 \xd8\xa7\xd9\x84\xd8\xb8\xd9\x87\xd8\xb1 ' + zuhr_time1 + ' \xd8\xad\xd8\xb3\xd8\xa8 \xd8\xaa\xd9\x88\xd9\x82\xd9\x8a\xd8\xaa ' + city + "  It's Now Zuhr  "
        if hrminute == asr_time:
            msgestr = '\n' + ' \xd8\xad\xd8\xa7\xd9\x86 \xd9\x85\xd9\x88\xd8\xb9\xd8\xaf \xd8\xb5\xd9\x84\xd8\xa7\xd8\xa9 \xd8\xa7\xd9\x84\xd8\xb9\xd8\xb5\xd8\xb1 ' + asr_time1 + ' \xd8\xad\xd8\xb3\xd8\xa8 \xd8\xaa\xd9\x88\xd9\x82\xd9\x8a\xd8\xaa ' + city + "  It's Now Asr  "
        if hrminute == maghrb_time:
            msgestr = '\n' + ' \xd8\xad\xd8\xa7\xd9\x86 \xd9\x85\xd9\x88\xd8\xb9\xd8\xaf \xd8\xb5\xd9\x84\xd8\xa7\xd8\xa9 \xd8\xa7\xd9\x84\xd9\x85\xd8\xba\xd8\xb1\xd8\xa8 ' + maghrb_time1 + ' \xd8\xad\xd8\xb3\xd8\xa8 \xd8\xaa\xd9\x88\xd9\x82\xd9\x8a\xd8\xaa ' + city + "  It's Now Maghrb  "
        if hrminute == esha_time:
            msgestr = '\n' + '\xd8\xad\xd8\xa7\xd9\x86 \xd9\x85\xd9\x88\xd8\xb9\xd8\xaf \xd8\xb5\xd9\x84\xd8\xa7\xd8\xa9 \xd8\xa7\xd9\x84\xd8\xb9\xd8\xb4\xd8\xa7\xd8\xa1 ' + esha_time1 + ' \xd8\xad\xd8\xb3\xd8\xa8 \xd8\xaa\xd9\x88\xd9\x82\xd9\x8a\xd8\xaa ' + city + "  It's Now Esha  "
        return msgestr
    except:
        return msgestr


def stoploop():
    StayLoop.stopTimer()


StayLoop = PrayerTimesBackgroundWorker(session)
