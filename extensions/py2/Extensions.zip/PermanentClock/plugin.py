## Permanent Clock ## by AliAbdul ## mod by Maggy 
from Components.ActionMap import ActionMap
from Components.config import config, ConfigInteger, ConfigSubsection, ConfigYesNo, getConfigListEntry, ConfigSelection, KEY_LEFT, KEY_RIGHT
from Components.Language import language
from Components.MenuList import MenuList
from Components.ConfigList import ConfigList
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.Pixmap import Pixmap
from enigma import ePoint, eTimer, getDesktop
from GlobalActions import globalActionMap
from keymapparser import readKeymap, removeKeymap
from os import environ
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
import gettext
from enigma import addFont
try:
    addFont("/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/Myclock.ttf", "Myclock", 100, 1)
    addFont("/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/font_default.otf", "ArabicFont", 100, 1)
    
except:
    pass
dwidth = getDesktop(0).size().width()
##############################################################################

config.plugins.PermanentClock = ConfigSubsection()
config.plugins.PermanentClock.enabled = ConfigYesNo(default=False)
config.plugins.PermanentClock.position_x = ConfigInteger(default=590)
config.plugins.PermanentClock.position_y = ConfigInteger(default=35)
config.plugins.PermanentClock.par1 = ConfigYesNo(default=False)
config.plugins.PermanentClock.show_hide = ConfigYesNo(default=False)
config.plugins.PermanentClock.color_analog = ConfigSelection([("1", _("maggy-style")),("2", _("maggy-breitling")),("3", _("maggy-tissot")),("4", _("maggy-ferrari")),("5", _("maggy-rolex")),("6", _("maggy-grand carrera")),("7", _("maggy-style2")),("8", _("maggy-style3")),("9", _("grey-metallic")),("10", _("black-yellow")),("11", _("atile-style")),("12", _("maggy-tron")),("13", _("maggy-globe")),("14", _("maggy-black")),("15", _("maggy-black-gold")),("16", _("maggy-omega")),("17", _("maggy-gt")),("18", _("sliver-red")),("19", _("hsv")),("20", _("fcb")),("21", _("bcb")),("22", _("christmas")),("23", _("carrera")),("24", _("porsche")),("25", _("nixon")),("26", _("luminor")),("27", _("blue")),("28", _("d-g")),("29", _("g-shock")),("30", _("maggy-carbon"))], default="1")


##############################################################################

def localeInit():
	lang = language.getLanguage()
	environ["LANGUAGE"] = lang[:2]
	gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
	gettext.textdomain("enigma2")
	gettext.bindtextdomain("PermanentClock", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/PermanentClock/locale/"))

def _(txt):
	t = gettext.dgettext("PermanentClock", txt)
	if t == txt:
		t = gettext.gettext(txt)
	return t

localeInit()
language.addCallback(localeInit)

##############################################################################

SKIN1 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock1.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")
	
##############################################################################

SKIN2 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock2.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN3 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock3.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

	##############################################################################

SKIN4 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock4.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")
	
##############################################################################

SKIN5 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock5.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN6 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock6.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN7 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock7.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN8 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock8.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN9 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock9.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN10 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock10.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN11 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock11.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN12 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock12.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN13 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock13.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN14 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock14.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN15 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock15.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN16 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock16.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN17 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock17.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN18 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock18.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN19 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock19.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN20 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock20.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN21 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock21.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN22 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock22.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN23 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock23.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN24 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock24.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN25 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock25.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN26 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock26.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN27 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock27.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN28 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock28.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN29 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock29.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################

SKIN30 = """
	<screen position="5,5" size="130,130" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="1,1" zPosition="1" size="130,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/clock30.png" alphatest="on" />
  <ePixmap position="61,61" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="24,24" size="82,82" zPosition="4" alphatest="on" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="26,26" size="77,77" zPosition="3" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="42,42" size="45,45" zPosition="2" foregroundColor="yellow" alphatest="on">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Permanent Clock")

##############################################################################
if dwidth == 1920:
    SKIN = """
	<screen position="0,0" size="182,80" zPosition="10" transparent="0" backgroundColor="transparent" title="%s" flags="wfNoBorder">
		<widget source="global.CurrentTime" render="Label" position="1,1" size="182,70" backgroundColor="transparent" transparent="1" zPosition="0" foregroundColor="#e65c00" font="Myclock;58" valign="center" halign="center">
			<convert type="ClockToText">Default</convert>
		</widget>
        <widget source="session.Event_Now" position="10,70" render="Progress" size="160,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/progress_infobar80.png" backgroundColor="un18080911" zPosition="5">
    <convert type="EventTime">Progress</convert>
  </widget>
	</screen>""" % _("Permanent Clock")

else:
    SKIN = """
	<screen position="0,0" size="140,70" zPosition="10" transparent="0" backgroundColor="transparent" title="%s" flags="wfNoBorder">
		<widget source="global.CurrentTime" render="Label" position="1,1" size="140,55" backgroundColor="transparent" transparent="1" zPosition="0" foregroundColor="#e65c00" font="Myclock;45" valign="center" halign="center">
			<convert type="ClockToText">Default</convert>
		</widget>
        <widget source="session.Event_Now" position="10,60" render="Progress" size="120,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/progress_infobar80.png" backgroundColor="un18080911" zPosition="5">
    <convert type="EventTime">Progress</convert>
  </widget>
	</screen>""" % _("Permanent Clock")


class PermanentClockNewScreen(Screen):
	def __init__(self, session):
		if config.plugins.PermanentClock.par1.value == True:
			if config.plugins.PermanentClock.color_analog.value == "1":
				self.skin = SKIN1
			elif config.plugins.PermanentClock.color_analog.value == "2":
				self.skin = SKIN2
			elif config.plugins.PermanentClock.color_analog.value == "3":
				self.skin = SKIN3
			elif config.plugins.PermanentClock.color_analog.value == "4":
				self.skin = SKIN4
			elif config.plugins.PermanentClock.color_analog.value == "5":
				self.skin = SKIN5
			elif config.plugins.PermanentClock.color_analog.value == "6":
				self.skin = SKIN6
			elif config.plugins.PermanentClock.color_analog.value == "7":
				self.skin = SKIN7
			elif config.plugins.PermanentClock.color_analog.value == "8":
				self.skin = SKIN8
			elif config.plugins.PermanentClock.color_analog.value == "9":
				self.skin = SKIN9
			elif config.plugins.PermanentClock.color_analog.value == "10":
				self.skin = SKIN10
			elif config.plugins.PermanentClock.color_analog.value == "11":
				self.skin = SKIN11
			elif config.plugins.PermanentClock.color_analog.value == "12":
				self.skin = SKIN12
			elif config.plugins.PermanentClock.color_analog.value == "13":
				self.skin = SKIN13
			elif config.plugins.PermanentClock.color_analog.value == "14":
				self.skin = SKIN14
			elif config.plugins.PermanentClock.color_analog.value == "15":
				self.skin = SKIN15
			elif config.plugins.PermanentClock.color_analog.value == "16":
				self.skin = SKIN16
			elif config.plugins.PermanentClock.color_analog.value == "17":
				self.skin = SKIN17
			elif config.plugins.PermanentClock.color_analog.value == "18":
				self.skin = SKIN18
			elif config.plugins.PermanentClock.color_analog.value == "19":
				self.skin = SKIN19
			elif config.plugins.PermanentClock.color_analog.value == "20":
				self.skin = SKIN20
			elif config.plugins.PermanentClock.color_analog.value == "21":
				self.skin = SKIN21
			elif config.plugins.PermanentClock.color_analog.value == "22":
				self.skin = SKIN22
			elif config.plugins.PermanentClock.color_analog.value == "23":
				self.skin = SKIN23
			elif config.plugins.PermanentClock.color_analog.value == "24":
				self.skin = SKIN24
			elif config.plugins.PermanentClock.color_analog.value == "25":
				self.skin = SKIN25
			elif config.plugins.PermanentClock.color_analog.value == "26":
				self.skin = SKIN26
			elif config.plugins.PermanentClock.color_analog.value == "27":
				self.skin = SKIN27
			elif config.plugins.PermanentClock.color_analog.value == "28":
				self.skin = SKIN28
			elif config.plugins.PermanentClock.color_analog.value == "29":
				self.skin = SKIN29
			elif config.plugins.PermanentClock.color_analog.value == "30":
				self.skin = SKIN30
		if config.plugins.PermanentClock.par1.value == False:
			self.skin = SKIN
		     
		Screen.__init__(self, session)
	    
		self.onShow.append(self.movePosition)

	def movePosition(self):
		if self.instance:
			self.instance.move(ePoint(config.plugins.PermanentClock.position_x.value, config.plugins.PermanentClock.position_y.value))

##############################################################################

class PermanentClock():
	def __init__(self):
		self.dialog = None
		self.clockShown = False
		self.clockey = False
		
	def gotSession(self, session):
		self.dialog = session.instantiateDialog(PermanentClockNewScreen)
		self.showHide()
		self.start_key()
		
	def start_key(self):
		global globalActionMap
		if config.plugins.PermanentClock.show_hide.value and self.clockey == False:
			readKeymap("/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/keymap.xml")
			globalActionMap.actions['showClock'] = self.ShowHideKey
			self.clockey = True

	def unload_key(self):
		if not config.plugins.PermanentClock.show_hide.value and self.clockey == True:
			removeKeymap("/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock/keymap.xml")
			if 'showClock' in globalActionMap.actions:
				del globalActionMap.actions['showClock']
			self.clockey = False
			
	def ShowHideKey(self):
		if config.plugins.PermanentClock.enabled.value:
			if self.clockShown:
				self.clockShown = False
				self.dialog.show()
			else:
				self.clockShown = True
				self.dialog.hide()
	
	
	def changeVisibility(self):
		if config.plugins.PermanentClock.enabled.value:
			config.plugins.PermanentClock.enabled.value = False
		else:
			config.plugins.PermanentClock.enabled.value = True
		config.plugins.PermanentClock.enabled.save()
		self.showHide()

	def changeAnalog(self):
		if config.plugins.PermanentClock.par1.value:
			config.plugins.PermanentClock.par1.value = False
		else:
			config.plugins.PermanentClock.par1.value = True
		config.plugins.PermanentClock.par1.save()
		self.dialog = None
		
	def ColorAnalog(self):
		config.plugins.PermanentClock.color_analog.save()
		self.dialog = None
		
	def changeKey(self):
		if config.plugins.PermanentClock.show_hide.value:
			config.plugins.PermanentClock.show_hide.value = False
		else:
			config.plugins.PermanentClock.show_hide.value = True
		config.plugins.PermanentClock.show_hide.save()	
		
	def showHide(self):
		if config.plugins.PermanentClock.enabled.value:
			self.dialog.show()
		else:
			self.dialog.hide()

pClock = PermanentClock()

##############################################################################

class PermanentClockPositioner(Screen):
	def __init__(self, session):
		if config.plugins.PermanentClock.par1.value == True:
			if config.plugins.PermanentClock.color_analog.value == "1":
				self.skin = SKIN1
			elif config.plugins.PermanentClock.color_analog.value == "2":
				self.skin = SKIN2
			elif config.plugins.PermanentClock.color_analog.value == "3":
				self.skin = SKIN3
			elif config.plugins.PermanentClock.color_analog.value == "4":
				self.skin = SKIN4
			elif config.plugins.PermanentClock.color_analog.value == "5":
				self.skin = SKIN5
			elif config.plugins.PermanentClock.color_analog.value == "6":
				self.skin = SKIN6
			elif config.plugins.PermanentClock.color_analog.value == "7":
				self.skin = SKIN7
			elif config.plugins.PermanentClock.color_analog.value == "8":
				self.skin = SKIN8
			elif config.plugins.PermanentClock.color_analog.value == "9":
				self.skin = SKIN9
			elif config.plugins.PermanentClock.color_analog.value == "10":
				self.skin = SKIN10
			elif config.plugins.PermanentClock.color_analog.value == "11":
				self.skin = SKIN11
			elif config.plugins.PermanentClock.color_analog.value == "12":
				self.skin = SKIN12
			elif config.plugins.PermanentClock.color_analog.value == "13":
				self.skin = SKIN13
			elif config.plugins.PermanentClock.color_analog.value == "14":
				self.skin = SKIN14
			elif config.plugins.PermanentClock.color_analog.value == "15":
				self.skin = SKIN15
			elif config.plugins.PermanentClock.color_analog.value == "16":
				self.skin = SKIN16
			elif config.plugins.PermanentClock.color_analog.value == "17":
				self.skin = SKIN17
			elif config.plugins.PermanentClock.color_analog.value == "18":
				self.skin = SKIN18
			elif config.plugins.PermanentClock.color_analog.value == "19":
				self.skin = SKIN19
			elif config.plugins.PermanentClock.color_analog.value == "20":
				self.skin = SKIN20
			elif config.plugins.PermanentClock.color_analog.value == "21":
				self.skin = SKIN21
			elif config.plugins.PermanentClock.color_analog.value == "22":
				self.skin = SKIN22
			elif config.plugins.PermanentClock.color_analog.value == "23":
				self.skin = SKIN23
			elif config.plugins.PermanentClock.color_analog.value == "24":
				self.skin = SKIN24
			elif config.plugins.PermanentClock.color_analog.value == "25":
				self.skin = SKIN25
			elif config.plugins.PermanentClock.color_analog.value == "26":
				self.skin = SKIN26
			elif config.plugins.PermanentClock.color_analog.value == "27":
				self.skin = SKIN27
			elif config.plugins.PermanentClock.color_analog.value == "28":
				self.skin = SKIN28
			elif config.plugins.PermanentClock.color_analog.value == "29":
				self.skin = SKIN29
			elif config.plugins.PermanentClock.color_analog.value == "30":
				self.skin = SKIN30
		if config.plugins.PermanentClock.par1.value == False:
			self.skin = SKIN
		Screen.__init__(self, session)
	
		
		self["actions"] = ActionMap(["WizardActions"],
		{
			"left": self.left,
			"up": self.up,
			"right": self.right,
			"down": self.down,
			"ok": self.ok,
			"back": self.exit
		}, -1)
		
		desktop = getDesktop(0)
		self.desktopWidth = desktop.size().width()
		self.desktopHeight = desktop.size().height()
		
		self.moveTimer = eTimer()
		self.moveTimer.callback.append(self.movePosition)
		self.moveTimer.start(50, 1)

	def movePosition(self):
		self.instance.move(ePoint(config.plugins.PermanentClock.position_x.value, config.plugins.PermanentClock.position_y.value))
		self.moveTimer.start(50, 1)

	def left(self):
		value = config.plugins.PermanentClock.position_x.value
		value -= 8
		if value < 0:
			value = 0
		config.plugins.PermanentClock.position_x.value = value

	def up(self):
		value = config.plugins.PermanentClock.position_y.value
		value -= 8
		if value < 0:
			value = 0
		config.plugins.PermanentClock.position_y.value = value

	def right(self):
		value = config.plugins.PermanentClock.position_x.value
		value += 8
		if value > self.desktopWidth:
			value = self.desktopWidth
		config.plugins.PermanentClock.position_x.value = value

	def down(self):
		value = config.plugins.PermanentClock.position_y.value
		value += 8
		if value > self.desktopHeight:
			value = self.desktopHeight
		config.plugins.PermanentClock.position_y.value = value

	def ok(self):
		config.plugins.PermanentClock.position_x.save()
		config.plugins.PermanentClock.position_y.save()
		self.close()

	def exit(self):
		config.plugins.PermanentClock.position_x.cancel()
		config.plugins.PermanentClock.position_y.cancel()
		self.close()

##############################################################################

class PermanentClockMenu(Screen):
    if dwidth == 1920:
        skin="""
        <screen  position="center,center" size="820,397" title="Permanent Clock Setup">
            <widget name="list" position="10,10" size="802,382" itemHeight="50" font="Regular; 35" />
        </screen>"""
    else:
        skin = """
		<screen position="center,center" size="410,155" title="Permanent Clock Setup">
			<widget name="list" position="10,10" size="400,145" itemHeight="40" font="Regular; 25" />
		</screen>""" 

    def __init__(self, session):
		Screen.__init__(self, session)
		self.session = session
		self["list"] = MenuList([])
		self.setTitle(_("Permanent Clock Setup"))
		self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.okClicked, "cancel": self.close}, -1)
		self.onLayoutFinish.append(self.showMenu)


    def showMenu(self):
		list = []
		if config.plugins.PermanentClock.enabled.value:
			list.append(_("Deactivate permanent clock"))
			list.append(_("Change permanent clock position"))
		else:
			list.append(_("Activate permanent clock"))
		if config.plugins.PermanentClock.enabled.value:
			if config.plugins.PermanentClock.par1.value:
				list.append(_("Show digital clock"))
				list.append(_("Change analog clock"))
			else:
				list.append(_("Show analog clock"))
		if config.plugins.PermanentClock.enabled.value:
			if config.plugins.PermanentClock.show_hide.value:
				list.append(_("Disable key 'long EXIT' show/nide"))
			else:
				list.append(_("Enable key 'long EXIT' show/nide"))
		self["list"].setList(list)



    def newConfig(self):
		pClock.dialog.hide()
		pClock.ColorAnalog()
		if pClock.dialog is None:
			pClock.gotSession(self.session)

					
    def okClicked(self):
		sel = self["list"].getCurrent()
		if pClock.dialog is None:
			pClock.gotSession(self.session)
		if sel == _("Deactivate permanent clock") or sel == _("Activate permanent clock"):
			pClock.changeVisibility()
			self.showMenu()
		if sel == _("Change permanent clock position") :
			pClock.dialog.hide()
			self.session.openWithCallback(self.positionerCallback, PermanentClockPositioner)
		if sel == _("Show analog clock") or sel == _("Show digital clock"):
			if pClock.dialog is not None:
				pClock.dialog.hide()
				pClock.changeAnalog()
				self.showMenu()
				if pClock.dialog is None:
					pClock.gotSession(self.session)
		if sel == _("Disable key 'long EXIT' show/nide"):
			if pClock.dialog is not None:
				pClock.changeKey()
				self.showMenu()
				pClock.unload_key()
		if sel == _("Enable key 'long EXIT' show/nide"):
			if pClock.dialog is not None:
				pClock.changeKey()
				self.showMenu()
				pClock.start_key()
		if sel == _("Change analog clock"):
			self.colorClock()
			
    def colorClock(self):
		list = [
			(_("maggy-style"), self.skins1),
			(_("maggy-breitling"), self.skins2),
			(_("maggy-tissot"), self.skins3),
			(_("maggy-ferrari"), self.skins4),
			(_("maggy-rolex"), self.skins5),
			(_("maggy-grand carrera"), self.skins6),
			(_("maggy-style2"), self.skins7),
			(_("maggy-style3"), self.skins8),
			(_("grey-metallic"), self.skins9),
			(_("black-yellow"), self.skins10),
			(_("atile-style"), self.skins11),
			(_("maggy-tron"), self.skins12),
			(_("maggy-globe"), self.skins13),
			(_("maggy-black"), self.skins14),
			(_("maggy-black-gold"), self.skins15),
			(_("maggy-omega"), self.skins16),
			(_("maggy-gt"), self.skins17),
			(_("silver-red"), self.skins18),
			(_("hsv"), self.skins19),
			(_("fcb"), self.skins20),
			(_("bvb"), self.skins21),
			(_("christmas"), self.skins22),
			(_("carrera"), self.skins23),
			(_("porsche"), self.skins24),
			(_("nixon"), self.skins25),
			(_("luminor"), self.skins26),
			(_("blue"), self.skins27),
			(_("d-g"), self.skins28),
			(_("g-shock"), self.skins29),
			(_("maggy-carbon"), self.skins30),
		]
		self.session.openWithCallback(
			self.menuCallback,
			ChoiceBox,
			title= _("Choice clock color:"),
			list = list,
		)

    def menuCallback(self, ret = None):
		ret and ret[1]()

    def positionerCallback(self, callback=None):
		pClock.showHide()

    def skins1(self):
		config.plugins.PermanentClock.color_analog.value = "1"
		self.newConfig()
		
    def skins2(self):
		config.plugins.PermanentClock.color_analog.value = "2"
		self.newConfig()

    def skins3(self):
		config.plugins.PermanentClock.color_analog.value = "3"
		self.newConfig()

    def skins4(self):
		config.plugins.PermanentClock.color_analog.value = "4"
		self.newConfig()

    def skins5(self):
		config.plugins.PermanentClock.color_analog.value = "5"
		self.newConfig()
		
    def skins6(self):
		config.plugins.PermanentClock.color_analog.value = "6"
		self.newConfig()
		
    def skins7(self):
		config.plugins.PermanentClock.color_analog.value = "7"
		self.newConfig()
		
    def skins8(self):
		config.plugins.PermanentClock.color_analog.value = "8"
		self.newConfig()
		
    def skins9(self):
		config.plugins.PermanentClock.color_analog.value = "9"
		self.newConfig()
		
    def skins10(self):
		config.plugins.PermanentClock.color_analog.value = "10"
		self.newConfig()
	
    def skins11(self):
		config.plugins.PermanentClock.color_analog.value = "11"
		self.newConfig()
	
    def skins12(self):
		config.plugins.PermanentClock.color_analog.value = "12"
		self.newConfig()
		
    def skins13(self):
		config.plugins.PermanentClock.color_analog.value = "13"
		self.newConfig()
		
    def skins14(self):
		config.plugins.PermanentClock.color_analog.value = "14"
		self.newConfig()
		
    def skins15(self):
		config.plugins.PermanentClock.color_analog.value = "15"
		self.newConfig()
	
    def skins16(self):
		config.plugins.PermanentClock.color_analog.value = "16"
		self.newConfig()
		
    def skins17(self):
		config.plugins.PermanentClock.color_analog.value = "17"
		self.newConfig()
		
    def skins18(self):
		config.plugins.PermanentClock.color_analog.value = "18"
		self.newConfig()
	
    def skins19(self):
		config.plugins.PermanentClock.color_analog.value = "19"
		self.newConfig()
		
    def skins20(self):
		config.plugins.PermanentClock.color_analog.value = "20"
		self.newConfig()
	
    def skins21(self):
		config.plugins.PermanentClock.color_analog.value = "21"
		self.newConfig()
		
    def skins22(self):
		config.plugins.PermanentClock.color_analog.value = "22"
		self.newConfig()
	
    def skins23(self):
		config.plugins.PermanentClock.color_analog.value = "23"
		self.newConfig()
		
    def skins24(self):
		config.plugins.PermanentClock.color_analog.value = "24"
		self.newConfig()
		
    def skins25(self):
		config.plugins.PermanentClock.color_analog.value = "25"
		self.newConfig()
	
    def skins26(self):
		config.plugins.PermanentClock.color_analog.value = "26"
		self.newConfig()
		
    def skins27(self):
		config.plugins.PermanentClock.color_analog.value = "27"
		self.newConfig()
		
    def skins28(self):
		config.plugins.PermanentClock.color_analog.value = "28"
		self.newConfig()
		
    def skins29(self):
		config.plugins.PermanentClock.color_analog.value = "29"
		self.newConfig()
		
    def skins30(self):
		config.plugins.PermanentClock.color_analog.value = "30"
		self.newConfig()
##############################################################################

def sessionstart(reason, **kwargs):
	if reason == 0:
		pClock.gotSession(kwargs["session"])

def startConfig(session, **kwargs):
	session.open(PermanentClockMenu)

def main(menuid):
	if menuid != "system": 
		return [ ]
	return [(_("Permanent Clock"), startConfig, "permanent_clock", None)]

##############################################################################

def Plugins(**kwargs):
	return [
		PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart),
		PluginDescriptor(name=_("Permanent Clock"), description=_("Shows the clock permanent on the screen"), where=PluginDescriptor.WHERE_MENU, fnc=main)]
