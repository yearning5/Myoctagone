## Permanent Caid ## mod by GUIRA 
from Components.ActionMap import ActionMap
from Components.config import config, ConfigInteger, ConfigSubsection, ConfigYesNo, getConfigListEntry, ConfigSelection, KEY_LEFT, KEY_RIGHT
from Components.Language import language
from Components.MenuList import MenuList
from Components.ConfigList import ConfigList
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.Pixmap import Pixmap
from enigma import ePoint, eTimer, getDesktop
from GlobalActions import globalActionMap
from keymapparser import readKeymap, removeKeymap
from os import environ
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
import gettext
dwidth = getDesktop(0).size().width()
##############################################################################

config.plugins.PermanentCaid = ConfigSubsection()
config.plugins.PermanentCaid.enabled = ConfigYesNo(default=False)
config.plugins.PermanentCaid.position_x = ConfigInteger(default=8)
config.plugins.PermanentCaid.position_y = ConfigInteger(default=4)
config.plugins.PermanentCaid.par1 = ConfigYesNo(default=False)
config.plugins.PermanentCaid.show_hide = ConfigYesNo(default=False)
config.plugins.PermanentCaid.color_analog = ConfigSelection([("1", _("maggy-style")),("2", _("maggy-breitling")),("3", _("maggy-tissot")),("4", _("maggy-ferrari")),("5", _("maggy-rolex")),("6", _("maggy-grand carrera")),("7", _("maggy-style2")),("8", _("maggy-style3")),("9", _("grey-metallic")),("10", _("black-yellow")),("11", _("atile-style")),("12", _("maggy-tron")),("13", _("maggy-globe")),("14", _("maggy-black")),("15", _("maggy-black-gold")),("16", _("maggy-omega")),("17", _("maggy-gt")),("18", _("sliver-red")),("19", _("hsv")),("20", _("fcb")),("21", _("bcb")),("22", _("christmas")),("23", _("carrera")),("24", _("porsche")),("25", _("nixon")),("26", _("luminor")),("27", _("blue")),("28", _("d-g")),("29", _("g-shock")),("30", _("maggy-carbon"))], default="1")


##############################################################################

def localeInit():
	lang = language.getLanguage()
	environ["LANGUAGE"] = lang[:2]
	gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
	gettext.textdomain("enigma2")
	gettext.bindtextdomain("PermanentCaid", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/PermanentCaid/locale/"))

def _(txt):
	t = gettext.dgettext("PermanentCaid", txt)
	if t == txt:
		t = gettext.gettext(txt)
	return t

localeInit()
language.addCallback(localeInit)

#from enigma import addFont
#try:
#    addFont("/usr/lib/enigma2/python/Plugins/Extensions/PermanentEvent/font/metal-mania.regular.ttf", "My1", 100, 1)
#    addFont("/usr/lib/enigma2/python/Plugins/Extensions/PermanentEvent/font/EventHD.ttf", "My2", 100, 1)
    
#except:
#    pass
##############################################################################

##############################################################################
if dwidth == 1920:
    SKIN = """
    <screen name="" position="1210,15" size="630,34" zPosition="-1" transparent="0" backgroundColor="transparent" title="%s" flags="wfNoBorder">
    <widget source="session.CurrentService" position="1,0" size="630,32" render="Label" font="global_small; 24" halign="center" valign="center" backgroundColor="infobarbackground" foregroundColor="#33ccff" transparent="1" noWrap="1">
	<convert type="MetrixHDCaidDisplay">Default</convert>
   </widget>
</screen>""" % _("Permanent Caid")

else:
    SKIN = """
	<screen name="" position="5,4" size="400,25" zPosition="-1" transparent="0" backgroundColor="transparent" title="%s" flags="wfNoBorder">
    <widget source="session.CurrentService" position="1,0" size="400,23" render="Label" font="global_small; 24" halign="center" valign="center" backgroundColor="infobarbackground" foregroundColor="#33ccff" transparent="1" noWrap="1">
	<convert type="MetrixHDCaidDisplay">Default</convert>
   </widget>
    </screen>""" % _("Permanent Caid")



class PermanentCaidNewScreen(Screen):
	def __init__(self, session):
		self.skin = SKIN
		     
		Screen.__init__(self, session)
	    
		self.onShow.append(self.movePosition)

	def movePosition(self):
		if self.instance:
			self.instance.move(ePoint(config.plugins.PermanentCaid.position_x.value, config.plugins.PermanentCaid.position_y.value))

##############################################################################

class PermanentCaid():
	def __init__(self):
		self.dialog = None
		self.clockShown = False
		self.clockey = False
		
	def gotSession(self, session):
		self.dialog = session.instantiateDialog(PermanentCaidNewScreen)
		self.showHide()
		self.start_key()
		
	def start_key(self):
		global globalActionMap
		if config.plugins.PermanentCaid.show_hide.value and self.clockey == False:
			readKeymap("/usr/lib/enigma2/python/Plugins/Extensions/PermanentCaid/keymap.xml")
			globalActionMap.actions['showClock'] = self.ShowHideKey
			self.clockey = True

	def unload_key(self):
		if not config.plugins.PermanentCaid.show_hide.value and self.clockey == True:
			removeKeymap("/usr/lib/enigma2/python/Plugins/Extensions/PermanentCaid/keymap.xml")
			if 'showClock' in globalActionMap.actions:
				del globalActionMap.actions['showClock']
			self.clockey = False
			
	def ShowHideKey(self):
		if config.plugins.PermanentCaid.enabled.value:
			if self.clockShown:
				self.clockShown = False
				self.dialog.show()
			else:
				self.clockShown = True
				self.dialog.hide()
	
	
	def changeVisibility(self):
		if config.plugins.PermanentCaid.enabled.value:
			config.plugins.PermanentCaid.enabled.value = False
		else:
			config.plugins.PermanentCaid.enabled.value = True
		config.plugins.PermanentCaid.enabled.save()
		self.showHide()
		
		
	def changeKey(self):
		if config.plugins.PermanentCaid.show_hide.value:
			config.plugins.PermanentCaid.show_hide.value = False
		else:
			config.plugins.PermanentCaid.show_hide.value = True
		config.plugins.PermanentCaid.show_hide.save()	
		
	def showHide(self):
		if config.plugins.PermanentCaid.enabled.value:
			self.dialog.show()
		else:
			self.dialog.hide()

pClock = PermanentCaid()

##############################################################################

class PermanentCaidPositioner(Screen):
	def __init__(self, session):
		self.skin = SKIN
		Screen.__init__(self, session)
	
		
		self["actions"] = ActionMap(["WizardActions"],
		{
			"left": self.left,
			"up": self.up,
			"right": self.right,
			"down": self.down,
			"ok": self.ok,
			"back": self.exit
		}, -1)
		
		desktop = getDesktop(0)
		self.desktopWidth = desktop.size().width()
		self.desktopHeight = desktop.size().height()
		
		self.moveTimer = eTimer()
		self.moveTimer.callback.append(self.movePosition)
		self.moveTimer.start(50, 1)

	def movePosition(self):
		self.instance.move(ePoint(config.plugins.PermanentCaid.position_x.value, config.plugins.PermanentCaid.position_y.value))
		self.moveTimer.start(50, 1)

	def left(self):
		value = config.plugins.PermanentCaid.position_x.value
		value -= 25
		if value < 0:
			value = 0
		config.plugins.PermanentCaid.position_x.value = value

	def up(self):
		value = config.plugins.PermanentCaid.position_y.value
		value -= 25
		if value < 0:
			value = 0
		config.plugins.PermanentCaid.position_y.value = value

	def right(self):
		value = config.plugins.PermanentCaid.position_x.value
		value += 25
		if value > self.desktopWidth:
			value = self.desktopWidth
		config.plugins.PermanentCaid.position_x.value = value

	def down(self):
		value = config.plugins.PermanentCaid.position_y.value
		value += 25
		if value > self.desktopHeight:
			value = self.desktopHeight
		config.plugins.PermanentCaid.position_y.value = value

	def ok(self):
		config.plugins.PermanentCaid.position_x.save()
		config.plugins.PermanentCaid.position_y.save()
		self.close()

	def exit(self):
		config.plugins.PermanentCaid.position_x.cancel()
		config.plugins.PermanentCaid.position_y.cancel()
		self.close()

##############################################################################

class PermanentCaidMenu(Screen):
    if dwidth == 1920:
        skin="""
        <screen name="" position="564,216" size="820,397" title="Permanent Caid Setup">
            <widget name="list" position="10,10" size="802,382" />
        </screen>"""
    else:
        skin = """
		<screen position="center,center" size="410,155" title="Permanent Caid Setup">
			<widget name="list" position="10,10" size="400,145" />
		</screen>""" 
    def __init__(self, session):
		Screen.__init__(self, session)
		self.session = session
		self["list"] = MenuList([])
		self.setTitle(_("Permanent Caid Setup"))
		self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.okClicked, "cancel": self.close}, -1)
		self.onLayoutFinish.append(self.showMenu)


    def showMenu(self):
		list = []
		if config.plugins.PermanentCaid.enabled.value:
			list.append(_("Deactivate Permanent Caid"))
			list.append(_("Change Permanent Caid position"))
		else:
			list.append(_("Activate Permanent Caid"))
		if config.plugins.PermanentCaid.enabled.value:
			if config.plugins.PermanentCaid.show_hide.value:
				list.append(_("Disable key 'long EXIT' show/nide"))
			else:
				list.append(_("Enable key 'long EXIT' show/nide"))
		self["list"].setList(list)



    def newConfig(self):
		pClock.dialog.hide()
		pClock.ColorAnalog()
		if pClock.dialog is None:
			pClock.gotSession(self.session)

					
    def okClicked(self):
		sel = self["list"].getCurrent()
		if pClock.dialog is None:
			pClock.gotSession(self.session)
		if sel == _("Deactivate Permanent Caid") or sel == _("Activate Permanent Caid"):
			pClock.changeVisibility()
			self.showMenu()
		if sel == _("Change Permanent Caid position") :
			pClock.dialog.hide()
			self.session.openWithCallback(self.positionerCallback, PermanentCaidPositioner)
		if sel == _("Disable key 'long EXIT' show/nide"):
			if pClock.dialog is not None:
				pClock.changeKey()
				self.showMenu()
				pClock.unload_key()
		if sel == _("Enable key 'long EXIT' show/Hide"):
			if pClock.dialog is not None:
				pClock.changeKey()
				self.showMenu()
				pClock.start_key()
			

    def menuCallback(self, ret = None):
		ret and ret[1]()

    def positionerCallback(self, callback=None):
		pClock.showHide()

##############################################################################

def sessionstart(reason, **kwargs):
	if reason == 0:
		pClock.gotSession(kwargs["session"])

def startConfig(session, **kwargs):
	session.open(PermanentCaidMenu)

def main(menuid):
	if menuid != "system": 
		return [ ]
	return [(_("Permanent Caid"), startConfig, "permanent_Caid", None)]

##############################################################################

def Plugins(**kwargs):
	return [
		PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart),
		PluginDescriptor(name=_("Permanent Caid"), description=_("Shows the Caid permanent on the screen"), where=PluginDescriptor.WHERE_MENU, fnc=main)]
